function validateRegisterForm() {
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    const passwordRegex = /^[a-zA-Z0-9]{8,12}$/;

    if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return false; // Prevent form submission
    }

    if (!passwordRegex.test(password)) {
        alert("Password must be 8-12 characters long and contain only letters and numbers.");
        return false; // Prevent form submission
    }

    return true; // Allow form submission
}

// Add event listener to the login button
document.getElementById('loginBtn').addEventListener('click', function() {
    window.location.href = 'login.php';
});

<?php
$carId = $_GET['carId'];

// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'carcarepro');

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch car details from the database
$sql = "SELECT * FROM cars WHERE id=$carId";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $carData = $result->fetch_assoc();

    // Fetch service details from the database
    $sql = "SELECT * FROM service_details WHERE car_id=$carId";
    $result = $conn->query($sql);

    $serviceDetails = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $serviceDetails[$row['service_type']] = [
                'lastChanged' => $row['last_changed'],
                'scheduledChange' => $row['scheduled_change']
            ];
        }
    }

    $carData['serviceDetails'] = [
        'oilLastChanged' => $serviceDetails['oil']['lastChanged'],
        'oilScheduledChange' => $serviceDetails['oil']['scheduledChange'],
        'tireLastChanged' => $serviceDetails['tire']['lastChanged'],
        'tireScheduledChange' => $serviceDetails['tire']['scheduledChange'],
        'otherMaintenance' => array_map(function ($type) use ($serviceDetails) {
            return [
                'item' => $type,
                'lastChanged' => $serviceDetails[$type]['lastChanged'],
                'scheduledChange' => $serviceDetails[$type]['scheduledChange']
            ];
        }, array_diff(array_keys($serviceDetails), ['oil', 'tire']))
    ];

    echo json_encode($carData);
} else {
    echo json_encode([]);
}

$conn->close();
?>

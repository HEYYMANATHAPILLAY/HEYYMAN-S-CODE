<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['schedule'])) {
        $car_id = $_POST['car_id'];
        $service_type = $_POST['service_type'];
        $appointment_date = $_POST['appointment_date'];
        
        $stmt = $conn->prepare("INSERT INTO appointments (user_id, car_id, service_type, appointment_date) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $user_id, $car_id, $service_type, $appointment_date);
        $stmt->execute();
        $stmt->close();
    } elseif (isset($_POST['update'])) {
        $appointment_id = $_POST['appointment_id'];
        $service_type = $_POST['service_type'];
        $appointment_date = $_POST['appointment_date'];

        $stmt = $conn->prepare("UPDATE appointments SET service_type=?, appointment_date=? WHERE appointment_id=? AND user_id=?");
        $stmt->bind_param("ssss", $service_type, $appointment_date, $appointment_id, $user_id);
        $stmt->execute();
        $stmt->close();
    } elseif (isset($_POST['cancel'])) {
        $appointment_id = $_POST['appointment_id'];

        $stmt = $conn->prepare("UPDATE appointments SET status='Cancelled' WHERE appointment_id=? AND user_id=?");
        $stmt->bind_param("ss", $appointment_id, $user_id);
        $stmt->execute();
        $stmt->close();
    } elseif (isset($_POST['delete'])) {
        $appointment_id = $_POST['appointment_id'];

        // Delete related staff assignments first
        $stmt = $conn->prepare("DELETE FROM staff_assignments WHERE appointment_id=?");
        $stmt->bind_param("i", $appointment_id);
        $stmt->execute();
        $stmt->close();

        // Now delete the appointment
        $stmt = $conn->prepare("DELETE FROM appointments WHERE appointment_id=? AND user_id=? AND status='Cancelled'");
        $stmt->bind_param("ss", $appointment_id, $user_id);
        $stmt->execute();
        $stmt->close();
    }
}

$appointments = [];
$stmt = $conn->prepare("SELECT a.*, c.make, c.model FROM appointments a JOIN cars c ON a.car_id = c.car_id WHERE a.user_id=?");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $appointments[] = $row;
}
$stmt->close();

$cars = [];
$stmt = $conn->prepare("SELECT * FROM cars WHERE user_id=?");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $cars[] = $row;
}
$stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Appointments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            background-attachment: fixed;
            background-image:url("background.jpg");
        }
        .container {
            width: 80%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            min-height: calc(100vh - 80px); /* Header and footer height */
        }
        h1, h2 {
            text-align: center;
            color: #333;
        }
        .section {
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .button2 {
            display: inline-block;
            transition: all 0.2s ease-in;
            position: relative;
            overflow: hidden;
            z-index: 1;
            color: #090909;
            padding: 0.7em 1.7em;
            cursor: pointer;
            font-size: 18px;
            border-radius: 0.5em;
            background: #e8e8e8;
            border: 1px solid #e8e8e8;
            box-shadow: 6px 6px 12px #c5c5c5, -6px -6px 12px #ffffff;
        }
        .button2:active {
            color: #666;
            box-shadow: inset 4px 4px 12px #c5c5c5, inset -4px -4px 12px #ffffff;
        }
        .button2:before {
            content: "";
            position: absolute;
            left: 50%;
            transform: translateX(-50%) scaleY(1) scaleX(1.25);
            top: 100%;
            width: 140%;
            height: 180%;
            background-color: rgba(0, 0, 0, 0.05);
            border-radius: 50%;
            display: block;
            transition: all 0.5s 0.1s cubic-bezier(0.55, 0, 0.1, 1);
            z-index: -1;
        }
        .button2:after {
            content: "";
            position: absolute;
            left: 55%;
            transform: translateX(-50%) scaleY(1) scaleX(1.45);
            top: 180%;
            width: 160%;
            height: 190%;
            background-color: #009087;
            border-radius: 50%;
            display: block;
            transition: all 0.5s 0.1s cubic-bezier(0.55, 0, 0.1, 1);
            z-index: -1;
        }
        .button2:hover {
            color: #ffffff;
            border: 1px solid #009087;
        }
        .button2:hover:before {
            top: -35%;
            background-color: #009087;
            transform: translateX(-50%) scaleY(1.3) scaleX(0.8);
        }
        .button2:hover:after {
            top: -45%;
            background-color: #009087;
            transform: translateX(-50%) scaleY(1.3) scaleX(0.8);
        }
    </style>
</head>
<body>
    <header>
        <?php include 'after-login-header.html'; ?>
    </header>
    <div class="container">
        <h1>User Appointments</h1>

        <div class="section">
            <h2>Schedule Appointment</h2>
            <form method="post" action="">
                <label for="car_id">Car:</label>
                <select name="car_id" id="car_id" required>
                    <?php foreach ($cars as $car): ?>
                        <option value="<?php echo htmlspecialchars($car['car_id']); ?>">
                            <?php echo htmlspecialchars($car['make'] . ' ' . $car['model']); ?>
                        </option>
                    <?php endforeach; ?>
                </select><br>
                <label for="service_type">Service Type:</label>
                <input type="text" name="service_type" id="service_type" required><br>
                <label for="appointment_date">Appointment Date:</label>
                <input type="datetime-local" name="appointment_date" id="appointment_date" required><br>
                <button type="submit" name="schedule" class="button2">Schedule</button>
            </form>
        </div>

        <div class="section">
            <h2>View/Edit Appointments</h2>
            <table>
                <tr>
                    <th>Car</th>
                    <th>Service Type</th>
                    <th>Appointment Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
                <?php foreach ($appointments as $appointment): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($appointment['make'] . ' ' . $appointment['model']); ?></td>
                        <td><?php echo htmlspecialchars($appointment['service_type']); ?></td>
                        <td><?php echo htmlspecialchars($appointment['appointment_date']); ?></td>
                        <td><?php echo htmlspecialchars($appointment['status']); ?></td>
                        <td>
                            <?php if ($appointment['status'] === 'Cancelled'): ?>
                                <form method="post" action="" style="display:inline;">
                                    <input type="hidden" name="appointment_id" value="<?php echo htmlspecialchars($appointment['appointment_id']); ?>">
                                    <button type="submit" name="delete" class="button2">Delete</button>
                                </form>
                            <?php else: ?>
                                <form method="post" action="" style="display:inline;">
                                    <input type="hidden" name="appointment_id" value="<?php echo htmlspecialchars($appointment['appointment_id']); ?>">
                                    <input type="text" name="service_type" value="<?php echo htmlspecialchars($appointment['service_type']); ?>" required>
                                    <input type="datetime-local" name="appointment_date" value="<?php echo htmlspecialchars(date('Y-m-d\TH:i', strtotime($appointment['appointment_date']))); ?>" required>
                                    <button type="submit" name="update" class="button2">Update</button>
                                    <button type="submit" name="cancel" class="button2">Cancel</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
    <footer style="position: relative; bottom: 0; width: 100%;">
        <?php include 'footer.html'; ?>
    </footer>
</body>
</html>

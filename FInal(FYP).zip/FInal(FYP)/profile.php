<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - CarCarePro</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background-color: #f4f4f4;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            background-attachment: fixed;
            background-image: url("background.jpg");
        }
        .content {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }
        .dashboard-container {
            width: 50%;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .dashboard-container h1 {
            text-align: center;
            color: #333;
        }
        .profile-picture {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            display: block;
            margin: 0 auto 20px auto;
        }
        .user-details {
            text-align: center;
        }
        .user-details p {
            margin: 10px 0;
        }
        .edit-button {
            padding: 10px 20px;
            border-radius: 5px;
            border: none;
            background-color: #007BFF;
            color: #fff;
            cursor: pointer;
            text-decoration: none;
        }
        .edit-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <header>
        <?php 
        if ($_SESSION['role'] === 'staff') {
            include 'after-login-header-staff.html';
        } else {
            include 'after-login-header.html';
        }
        ?>
    </header>
    <div class="content">
        <div class="dashboard-container">
            <h1>Welcome to your Carcarepro profile, <?php echo htmlspecialchars($user['first_name']); ?></h1>
            <?php if ($user['ImageFile']): ?>
                <img src="assets/images/users/<?php echo htmlspecialchars($user['ImageFile']); ?>" alt="Profile Picture" class="profile-picture">
            <?php else: ?>
                <img src="default-profile.png" alt="Default Profile Picture" class="profile-picture">
            <?php endif; ?>
            <div class="user-details">
                <p><strong>First Name:</strong> <?php echo htmlspecialchars($user['first_name']); ?></p>
                <p><strong>Last Name:</strong> <?php echo htmlspecialchars($user['last_name']); ?></p>
                <p><strong>Phone:</strong> <?php echo htmlspecialchars($user['phone']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                <p><strong>Info:</strong> <?php echo htmlspecialchars($user['info']); ?></p>
                <p><strong>Role:</strong> <?php echo ucfirst(htmlspecialchars($user['role'])); ?></p>
                <p><strong>Status:</strong> <?php echo $user['status'] ? 'Active' : 'Inactive'; ?></p>
            </div>
            <a href="editprofile.php" class="edit-button">Edit Profile</a>
        </div>
    </div>
    <footer>
        <?php include 'footer.html'; ?>
    </footer>
</body>
</html>

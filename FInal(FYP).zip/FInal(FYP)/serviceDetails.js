document.addEventListener('DOMContentLoaded', () => {
    const params = new URLSearchParams(window.location.search);
    const carId = params.get('carId');

    fetch(`/api/service-details/${carId}`)
        .then(response => response.json())
        .then(carData => {
            document.getElementById('carVin').innerText = carData.vin;
            document.getElementById('carMake').innerText = carData.make;
            document.getElementById('carModel').innerText = carData.model;
            document.getElementById('carYear').innerText = carData.year;
            document.getElementById('oilLastChanged').innerText = carData.serviceDetails.oilLastChanged;
            document.getElementById('oilScheduledChange').innerText = carData.serviceDetails.oilScheduledChange;
            document.getElementById('tireLastChanged').innerText = carData.serviceDetails.tireLastChanged;
            document.getElementById('tireScheduledChange').innerText = carData.serviceDetails.tireScheduledChange;

            const otherMaintenanceDiv = document.getElementById('otherMaintenance');
            carData.serviceDetails.otherMaintenance.forEach(item => {
                const maintenanceItem = document.createElement('div');
                maintenanceItem.innerHTML = `
                    <p><strong>${item.item}</strong></p>
                    <p><strong>Last changed:</strong> ${item.lastChanged}</p>
                    <p><strong>Scheduled change:</strong> ${item.scheduledChange}</p>
                `;
                otherMaintenanceDiv.appendChild(maintenanceItem);
            });
        })
        .catch(error => console.error('Error fetching service details:', error));
});

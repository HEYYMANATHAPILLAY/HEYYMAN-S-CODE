<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html');
    exit();
}

$user_id = $_SESSION['user_id'];

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user feedback and responses
$sql = "SELECT f.id as feedback_id, f.feedback, f.submitted_at, f.status, r.response, r.responded_at, u.email as staff_email
        FROM feedback f
        LEFT JOIN responses r ON f.id = r.feedback_id
        LEFT JOIN users u ON r.staff_id = u.id
        WHERE f.user_id = ?
        ORDER BY f.submitted_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply'])) {
    $feedback_id = $_POST['feedback_id'];
    $user_response = $_POST['user_response'];

    // Insert the user's reply into the feedback table
    $stmt = $conn->prepare("INSERT INTO feedback (user_id, feedback, submitted_at, status) VALUES (?, ?, NOW(), 'pending')");
    $stmt->bind_param("ss", $user_id, $user_response);

    if ($stmt->execute()) {
        echo "<script>alert('Response submitted successfully.');</script>";
        // Refresh to show the new response
        header("Location: viewFeedback.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Feedback and Responses</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            min-height: 100%;
            display: flex;
            flex-direction: column;
            background-color: #CCCCCC;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            background-attachment: fixed;
            background-image: url("background.jpg");
        }

        .container {
            flex: 1;
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }
        h1 {
            text-align: center;
        }
        .feedback {
            border-bottom: 1px solid #dee2e6;
            padding: 10px 0;
        }
        .feedback:last-child {
            border-bottom: none;
        }
        .feedback p {
            margin: 5px 0;
        }
        .response {
            margin-left: 20px;
            padding-left: 10px;
            border-left: 3px solid #007BFF;
        }
        .response p {
            margin: 5px 0;
        }
        .status {
            color: green;
            font-weight: bold;
        }
        .no-feedback {
            text-align: center;
            font-size: 1.2em;
        }
        .reply-form {
            margin-top: 10px;
        }
        .reply-form textarea {
            width: 100%;
            height: 100px;
            margin-bottom: 10px;
        }
        .reply-form button {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
        }
        .reply-form button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <header>
        <?php include 'after-login-header.html'; ?>
    </header>
    <div class="container">
        <h1>Your Feedback and Responses</h1>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='feedback'>";
                echo "<p><strong>Feedback:</strong> " . nl2br(htmlspecialchars($row['feedback'])) . "</p>";
                echo "<p><strong>Submitted at:</strong> " . htmlspecialchars($row['submitted_at']) . "</p>";
                echo "<p class='status'><strong>Status:</strong> " . htmlspecialchars($row['status']) . "</p>";

                if ($row['response']) {
                    echo "<div class='response'>";
                    echo "<p><strong>Response from " . htmlspecialchars($row['staff_email']) . ":</strong></p>";
                    echo "<p>" . nl2br(htmlspecialchars($row['response'])) . "</p>";
                    echo "<p><strong>Responded at:</strong> " . htmlspecialchars($row['responded_at']) . "</p>";
                    echo "</div>";
                }

                echo "<div class='reply-form'>";
                echo "<form method='POST' action=''>";
                echo "<input type='hidden' name='feedback_id' value='" . htmlspecialchars($row['feedback_id']) . "'>";
                echo "<textarea name='user_response' placeholder='Write your reply here...' required></textarea>";
                echo "<button type='submit' name='reply'>Submit Reply</button>";
                echo "</form>";
                echo "</div>";

                echo "</div>";
            }
        } else {
            echo "<p class='no-feedback'>No feedback found.</p>";
        }
        ?>
    </div>
    <footer>
        <?php include 'footer.html'; ?>
    </footer>
</body>
</html>

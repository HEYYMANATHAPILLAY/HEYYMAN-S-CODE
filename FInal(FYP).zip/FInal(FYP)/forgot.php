<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reset_success = false;
$reset_error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if ($new_password !== $confirm_password) {
        $reset_error = "Passwords do not match.";
    } else {
        // Do not hash the password
        $plain_password = $new_password;

        $sql = "SELECT * FROM users WHERE email = '$email' AND phone = '$phone'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $update_sql = "UPDATE users SET password = '$plain_password' WHERE email = '$email' AND phone = '$phone'";
            if ($conn->query($update_sql) === TRUE) {
                $reset_success = true;
                // Redirect to login page after a short delay
                header("refresh:2; url=login.php");
            } else {
                $reset_error = "Error updating password: " . $conn->error;
            }
        } else {
            $reset_error = "No user found with this email and phone number.";
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CarCarePro Forgot Password</title>
    <link rel="stylesheet" href="forgot.css">
    <script>
        <?php if ($reset_success): ?>
            alert("Password reset successfully. Redirecting to login page...");
            window.location.href = "login.php";
        <?php elseif (!empty($reset_error)): ?>
            alert("<?php echo $reset_error; ?>");
        <?php endif; ?>
    </script>
</head>
<body>
    <div class="container">
        <div class="forgot-section">
            <h1>CarCarePro</h1>
            <h2>Forgot Password?</h2>
            <form class="forgot-form" method="POST" action="">
                <input type="email" name="email" id="email" placeholder="example123@gmail.com" required>
                <input type="tel" name="phone" id="phone" placeholder="+60 123456789" required>
                <input type="password" name="new_password" id="new-password" placeholder="New Password" required>
                <input type="password" name="confirm_password" id="confirm-password" placeholder="Confirm Password" required>
                <button type="submit" class="submit-btn">&#10140;</button>
            </form>
        </div>
        <div class="image-section">
            <img src="car-login.jpg" alt="Car Image">
        </div>
    </div>
    <script src="forgot.js"></script>
</body>
</html>

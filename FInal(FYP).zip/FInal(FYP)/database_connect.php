<?php
session_start(); // Start the session to access session variables

function OpenCon(){
    $dbhost = "localhost";
    $dbname = "carcarepro";
    $dbuser = "root";
    $dbpass = "";

    $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    return $conn;
}

function CloseCon($conn){
    $conn->close();
}

function checkUserRole($conn, $userId) {
    $sql = "SELECT role FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['role'];
    } else {
        return null;
    }
}

// Assuming the user's ID is stored in the session upon login
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    
    if (!isset($_SESSION['user_role'])) {
        // Fetch user role from the database if not already set in session
        $conn = OpenCon();
        $userRole = checkUserRole($conn, $userId);
        CloseCon($conn);

        if ($userRole) {
            $_SESSION['user_role'] = $userRole;
        } else {
            // Handle the case where the user ID does not exist in the database
            header("Location: logout.php");
            exit();
        }
    }

    if ($_SESSION['user_role'] !== 'admin') {
        // User is not admin, show alert and redirect
        echo "<script type='text/javascript'>
                alert('Only admins allowed here.');
                setTimeout(function() {
                    window.location.href = 'logout.php';
                }, 5000);
              </script>";
        exit();
    }
} else {
    // No user ID in session, redirect to logout
    header("Location: logout.php");
    exit();
}
?>

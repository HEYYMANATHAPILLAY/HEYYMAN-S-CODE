<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$selected_user_id = $user_id;
$error = '';
$success = '';

// Function to calculate car health based on mileage and year
function calculateCarHealth($mileage, $year) {
    $currentYear = date("Y");
    $carAge = $currentYear - $year;

    if ($mileage < 50000 && $carAge < 5) {
        return "Excellent";
    } elseif ($mileage < 100000 && $carAge < 10) {
        return "Good";
    } elseif ($mileage < 150000 && $carAge < 15) {
        return "Fair";
    } else {
        return "Poor";
    }
}

// Fetch user information
$user_info_stmt = $conn->prepare("SELECT * FROM users WHERE id=?");
$user_info_stmt->bind_param("s", $user_id);
$user_info_stmt->execute();
$user_info = $user_info_stmt->get_result()->fetch_assoc();
$user_info_stmt->close();

// Fetch all users for staff to select
$all_users = [];
if ($role === 'staff') {
    $user_stmt = $conn->prepare("SELECT id, first_name, last_name FROM users WHERE role='user'");
    $user_stmt->execute();
    $users_result = $user_stmt->get_result();
    while ($user = $users_result->fetch_assoc()) {
        $all_users[] = $user;
    }
    $user_stmt->close();
    if (isset($_GET['user_id'])) {
        $selected_user_id = $_GET['user_id'];
    } else {
        $selected_user_id = $all_users[0]['id']; // Default to the first user
    }
}

// Fetch car information for the logged-in user or selected user
$car_info_stmt = $conn->prepare("SELECT * FROM cars WHERE user_id=?");
$car_info_stmt->bind_param("s", $selected_user_id);
$car_info_stmt->execute();
$car_info_result = $car_info_stmt->get_result();
$car_info_stmt->close();

$cars = [];
while ($row = $car_info_result->fetch_assoc()) {
    $cars[] = $row;
}

// Fetch maintenance history
$maintenance_history_stmt = $conn->prepare("SELECT * FROM services WHERE car_id IN (SELECT car_id FROM cars WHERE user_id=?) ORDER BY last_changed DESC");
$maintenance_history_stmt->bind_param("s", $selected_user_id);
$maintenance_history_stmt->execute();
$maintenance_history_result = $maintenance_history_stmt->get_result();
$maintenance_history_stmt->close();

$maintenance_history = [];
while ($row = $maintenance_history_result->fetch_assoc()) {
    $maintenance_history[] = $row;
}

// Fetch upcoming maintenance (example based on scheduled change)
$upcoming_maintenance_stmt = $conn->prepare("SELECT * FROM services WHERE car_id IN (SELECT car_id FROM cars WHERE user_id=?) AND scheduled_change > NOW() ORDER BY scheduled_change ASC");
$upcoming_maintenance_stmt->bind_param("s", $selected_user_id);
$upcoming_maintenance_stmt->execute();
$upcoming_maintenance_result = $upcoming_maintenance_stmt->get_result();
$upcoming_maintenance_stmt->close();

$upcoming_maintenance = [];
while ($row = $upcoming_maintenance_result->fetch_assoc()) {
    $upcoming_maintenance[] = $row;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            background-attachment: fixed;
            background-image: url("background.jpg");
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            flex: 1;
        }
        h1, h2, h3 {
            text-align: center;
            color: #333;
        }
        .section {
            margin-top: 20px;
        }
        .car-info, .maintenance-history, .upcoming-maintenance {
            width: 100%;
            border-collapse: collapse;
        }
        .car-info th, .maintenance-history th, .upcoming-maintenance th, 
        .car-info td, .maintenance-history td, .upcoming-maintenance td {
            border: 1px solid #ddd;
            padding: 12px;
        }
        .car-info th, .maintenance-history th, .upcoming-maintenance th {
            background-color: #f2f2f2;
            text-align: left;
        }
        .car-info tr:nth-child(even), .maintenance-history tr:nth-child(even), 
        .upcoming-maintenance tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .car-info tr:hover, .maintenance-history tr:hover, 
        .upcoming-maintenance tr:hover {
            background-color: #f1f1f1;
        }
        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            position: relative;
            bottom: 0;
            width: 100%;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group select, .form-group button {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
        }
    </style>
</head>
<body>
    <header>
        <?php 
        if ($role === 'staff') {
            include 'after-login-header-staff.html';
        } else {
            include 'after-login-header.html';
        }
        ?>
    </header>
    <div class="container">
        <h1>Dashboard</h1>
        <h2>Welcome, <?php echo htmlspecialchars($user_info['first_name'] . ' ' . $user_info['last_name']); ?></h2>
        
        <?php if ($role === 'staff'): ?>
            <form method="GET" action="">
                <div class="form-group">
                    <label for="user_id">Select User:</label>
                    <select name="user_id" id="user_id" onchange="this.form.submit()">
                        <?php foreach ($all_users as $user): ?>
                            <option value="<?php echo htmlspecialchars($user['id']); ?>" <?php if ($user['id'] == $selected_user_id) echo 'selected'; ?>>
                                <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </form>
        <?php endif; ?>

        <div class="section">
            <h3>Overall Car Health</h3>
            <table class="car-info">
                <tr>
                    <th>Car</th>
                    <th>Mileage</th>
                    <th>Year</th>
                    <th>Health</th>
                </tr>
                <?php foreach ($cars as $car): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($car['make'] . ' ' . $car['model']); ?></td>
                        <td><?php echo htmlspecialchars($car['mileage']); ?></td>
                        <td><?php echo htmlspecialchars($car['year']); ?></td>
                        <td><?php echo calculateCarHealth($car['mileage'], $car['year']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>

        <div class="section">
            <h3>Upcoming Maintenance</h3>
            <table class="upcoming-maintenance">
                <tr>
                    <th>Date</th>
                    <th>Service</th>
                    <th>Next Scheduled Change</th>
                </tr>
                <?php foreach ($upcoming_maintenance as $maintenance): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($maintenance['scheduled_change']); ?></td>
                        <td><?php echo htmlspecialchars($maintenance['service_type']); ?></td>
                        <td><?php echo htmlspecialchars($maintenance['scheduled_change']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>

        <div class="section">
            <h3>Maintenance History</h3>
            <table class="maintenance-history">
                <tr>
                    <th>Date</th>
                    <th>Service</th>
                    <th>Last Changed</th>
                </tr>
                <?php foreach ($maintenance_history as $history): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($history['last_changed']); ?></td>
                        <td><?php echo htmlspecialchars($history['service_type']); ?></td>
                        <td><?php echo htmlspecialchars($history['last_changed']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
    <footer>
        <?php include 'footer.html'; ?>
    </footer>
</body>
</html>

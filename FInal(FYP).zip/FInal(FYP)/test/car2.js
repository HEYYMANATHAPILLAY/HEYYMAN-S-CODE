document.getElementById('addCarButton').addEventListener('click', function() {
    document.getElementById('addCarForm').classList.toggle('hidden');
});

const cars = [];

function addCar(event) {
    event.preventDefault();
    const make = document.getElementById('make').value;
    const model = document.getElementById('model').value;
    const year = document.getElementById('year').value;
    const mileage = document.getElementById('mileage').value;

    const car = {
        id: Date.now(),
        make,
        model,
        year,
        mileage
    };

    cars.push(car);
    displayCars();
    document.getElementById('addCarForm').reset();
    document.getElementById('addCarForm').classList.add('hidden');
}

function displayCars() {
    const carTableBody = document.getElementById('carTableBody');
    carTableBody.innerHTML = '';

    cars.forEach(car => {
        const carRow = document.createElement('tr');
        carRow.innerHTML = `
            <td>${car.make}</td>
            <td>${car.model}</td>
            <td>${car.year}</td>
            <td>${car.mileage}</td>
            <td>
                <button class="edit" onclick="editCar(${car.id})"><span>Edit</span></button>
                <button class="delete" onclick="deleteCar(${car.id})"><span>Delete</span></button>
            </td>
        `;
        carTableBody.appendChild(carRow);
    });
}

function editCar(id) {
    const car = cars.find(c => c.id === id);
    document.getElementById('editCarId').value = car.id;
    document.getElementById('editMake').value = car.make;
    document.getElementById('editModel').value = car.model;
    document.getElementById('editYear').value = car.year;
    document.getElementById('editMileage').value = car.mileage;
    document.getElementById('editCarForm').classList.remove('hidden');
}

function updateCar(event) {
    event.preventDefault();
    const id = document.getElementById('editCarId').value;
    const make = document.getElementById('editMake').value;
    const model = document.getElementById('editModel').value;
    const year = document.getElementById('editYear').value;
    const mileage = document.getElementById('editMileage').value;

    const carIndex = cars.findIndex(c => c.id == id);
    cars[carIndex] = { id: Number(id), make, model, year, mileage };
    displayCars();
    document.getElementById('editCarForm').reset();
    document.getElementById('editCarForm').classList.add('hidden');
}

function deleteCar(id) {
    const carIndex = cars.findIndex(c => c.id === id);
    cars.splice(carIndex, 1);
    displayCars();
}

displayCars();

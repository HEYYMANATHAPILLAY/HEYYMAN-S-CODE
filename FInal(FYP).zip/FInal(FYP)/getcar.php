<?php
$id = $_GET['id'];

// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'carcarepro');

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch car details from the database
$sql = "SELECT * FROM cars WHERE id=$id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of the fetched row
    echo json_encode($result->fetch_assoc());
} else {
    echo json_encode([]);
}

$conn->close();
?>

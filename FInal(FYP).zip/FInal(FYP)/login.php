<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$login_success = false;
$login_error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        if ($user['status'] == 0) {
            $login_error = "Please contact admin to reactivate your account.";
        } elseif ($password === $user['password']) { // Plain text password comparison
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $login_success = true;
        } else {
            $login_error = "Invalid password.";
        }
    } else {
        $login_error = "No user found with this email.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CarCarePro Login</title>
    <link rel="stylesheet" href="login.css">
    <script>
        <?php if ($login_success): ?>
            alert("Login successful!");
            <?php if ($_SESSION['role'] == 'admin'): ?>
                window.location.href = "index.php";
            <?php else: ?>
                window.location.href = "dashboard.php";
            <?php endif; ?>
        <?php elseif (!empty($login_error)): ?>
            alert("<?php echo $login_error; ?>");
            <?php if ($login_error == "Please contact admin to reactivate your account."): ?>
                window.location.href = "feedbackguest.php";
            <?php endif; ?>
        <?php endif; ?>
    </script>
</head>
<body>
    <div class="container">
        <div class="login-section">
            <h1>CarCarePro</h1>
            <div class="buttons">
                <button class="login-btn active">Log In</button>
                <button class="create-account-btn" id="createAccountBtn">Create Account</button>
            </div>
            <h2>Welcome Back!</h2>
            <form class="login-form" method="POST" action="">
                <input type="email" name="email" placeholder="example123@gmail.com" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" class="submit-btn">&#10140;</button>
            </form>
            <a href="forgot.php" class="forgot-password">Forgot Password?</a>
        </div>
        <div class="image-section">
            <img src="car-login.jpg" alt="Car Image">
        </div>
    </div>
    <script src="login.js"></script>
</body>
</html>

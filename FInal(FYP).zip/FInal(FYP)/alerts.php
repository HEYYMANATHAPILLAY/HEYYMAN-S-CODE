<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user information
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Fetch user alerts
$alerts_sql = "SELECT * FROM alerts WHERE user_id = ? ORDER BY date DESC";
$stmt = $conn->prepare($alerts_sql);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$alerts_result = $stmt->get_result();
$alerts = $alerts_result->fetch_all(MYSQLI_ASSOC);

// Handle new alert creation
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['event-name'], $_POST['event-date'], $_POST['event-time'])) {
        $eventName = $_POST['event-name'];
        $eventDate = $_POST['event-date'];
        $eventTime = $_POST['event-time'];

        $stmt = $conn->prepare("INSERT INTO alerts (user_id, name, date, time) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $user_id, $eventName, $eventDate, $eventTime);
        $stmt->execute();
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } elseif (isset($_POST['scheduled-service'])) {
        $service_id = $_POST['scheduled-service'];

        $service_sql = "SELECT service_type, scheduled_change FROM services WHERE service_id = ?";
        $stmt = $conn->prepare($service_sql);
        $stmt->bind_param("i", $service_id);
        $stmt->execute();
        $service_result = $stmt->get_result();
        $service = $service_result->fetch_assoc();

        $eventName = "Scheduled service: " . $service['service_type'];
        $eventDate = $service['scheduled_change'];
        $eventTime = "00:00:00";  // Default time for the scheduled change

        $stmt = $conn->prepare("INSERT INTO alerts (user_id, name, date, time) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $user_id, $eventName, $eventDate, $eventTime);
        $stmt->execute();
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CARCAREPRO REMINDER</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('CARCAREPROPIC.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
            flex-direction: column;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            background-attachment: fixed;
            background-image:url("background.jpg");
        }
        h1 {
            font-size: 55px;
            color: #fbf6f6;
            text-shadow: 0 0 10px rgba(9, 9, 9, 0.5),
                         0 0 20px rgba(9, 9, 9, 0.5),
                         0 0 30px rgba(9, 9, 9, 0.5);
            position: absolute;
            top: 20px;
            left: 20px;
            margin: 0;
        }
        .container {
            width: 100%;
            max-width: 600px;
            background-color: #ffffffcc;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input, button, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #007BFF;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        #alerts-history {
            margin-top: 20px;
        }
        .alert {
            background-color: #f9f9f9;
            padding: 10px;
            margin-bottom: 10px;
            border-left: 5px solid #007BFF;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
        }
        .modal-content {
            background-color: #cccccc;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 300px;
            text-align: center;
            position: relative;
            top: 10px;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        .ok-button {
            background-color: #007BFF;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            margin-top: 20px;
        }
        .ok-button:hover {
            background-color: #0056b3;
        }
        .bell-icon {
            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 24px;
            cursor: pointer;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 20px;
            top: 50px;
            background-color: #f9f9f9;
            min-width: 250px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
            border-radius: 8px;
            padding: 10px;
            box-sizing: border-box;
        }
        .dropdown-content div {
            padding: 10px;
            border-bottom: 1px solid #ccc;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .dropdown-content div:last-child {
            border-bottom: none;
        }
        .dropdown-content.show {
            display: block;
        }
        .delete-icon {
            cursor: pointer;
            font-size: 20px;
            color: red;
        }
        .back-button {
            background-color: #28a745;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            margin-top: 20px;
        }
        .back-button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

<h1>Welcome, <?php echo htmlspecialchars($user['first_name']); ?>!</h1>

<div class="bell-icon" onclick="toggleDropdown()">🔔</div>

<div id="dropdown" class="dropdown-content">
    <h3>Upcoming Events</h3>
    <div id="dropdown-events">
        <?php foreach ($alerts as $alert): 
            $alertDateTime = new DateTime($alert['date'] . ' ' . $alert['time']);
            $now = new DateTime();
            if ($alertDateTime >= $now): ?>
                <div>
                    Event: <?php echo htmlspecialchars($alert['name']); ?> | Date: <?php echo htmlspecialchars($alert['date']); ?> | Time: <?php echo htmlspecialchars($alert['time']); ?> 
                    <span class="delete-icon" onclick="deleteAlert(<?php echo $alert['id']; ?>)">🗑️</span>
                </div>
            <?php endif; 
        endforeach; ?>
    </div>
</div>

<div class="container">
    <div>
        <h2>Set an Alert</h2>
        <form method="post">
            <label for="event-name">Event Name</label>
            <input type="text" id="event-name" name="event-name" placeholder="Enter event name" required>
            <label for="event-date">Date</label>
            <input type="date" id="event-date" name="event-date" required>
            <label for="event-time">Time</label>
            <input type="time" id="event-time" name="event-time" required>
            <button type="submit">Set Alert</button>
        </form>
    </div>

    <div>
        <h2>Schedule a Service Alert</h2>
        <form method="post">
            <label for="scheduled-service">Select a Scheduled Service</label>
            <select id="scheduled-service" name="scheduled-service" required>
                <?php
                // Fetch services for the user's cars
                $services_sql = "SELECT s.service_id, s.service_type, s.scheduled_change 
                                 FROM services s 
                                 JOIN cars c ON s.car_id = c.car_id 
                                 WHERE c.user_id = ?";
                $stmt = $conn->prepare($services_sql);
                $stmt->bind_param("s", $user_id);
                $stmt->execute();
                $services_result = $stmt->get_result();

                if ($services_result->num_rows > 0) {
                    while ($service = $services_result->fetch_assoc()) {
                        echo "<option value='{$service['service_id']}'>{$service['service_type']} - {$service['scheduled_change']}</option>";
                    }
                } else {
                    echo "<option value='' disabled>No scheduled services found</option>";
                }
                ?>
            </select>
            <button type="submit">Schedule Alert</button>
        </form>
    </div>

    <div id="alerts-history">
        <h2>Past Events</h2>
        <?php foreach ($alerts as $alert): 
            $alertDateTime = new DateTime($alert['date'] . ' ' . $alert['time']);
            $now = new DateTime();
            if ($alertDateTime < $now): ?>
                <div class="alert">
                    Event: <?php echo htmlspecialchars($alert['name']); ?> | Date: <?php echo htmlspecialchars($alert['date']); ?> | Time: <?php echo htmlspecialchars($alert['time']); ?>
                    <span class="delete-icon" onclick="deleteAlert(<?php echo $alert['id']; ?>)">🗑️</span>
                </div>
            <?php endif; 
        endforeach; ?>
    </div>
</div>

<!-- Back Button -->
<form action="dashboard.php">
    <button type="submit" class="back-button">Back to Dashboard</button>
</form>

<script>
    function toggleDropdown() {
        const dropdown = document.getElementById('dropdown');
        dropdown.classList.toggle('show');
    }

    function deleteAlert(alertId) {
        if (confirm('Are you sure you want to delete this alert?')) {
            window.location.href = 'delete_alert.php?id=' + alertId;
        }
    }

    const modal = document.getElementById('myModal');
    const span = document.getElementsByClassName('close')[0];

    span.onclick = function() {
        modal.style.display = 'none';
    }

    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = 'none';
        } else if (!event.target.matches('.bell-icon')) {
            const dropdown = document.getElementById('dropdown');
            if (dropdown.classList.contains('show')) {
                dropdown.classList.remove('show');
            }
        }
    }

    function showModal(message) {
        const modalText = document.getElementById('modal-text');
        modalText.innerText = message;
        modal.style.display = 'block';
    }
</script>
</body>
</html>

<?php
$conn->close();
?>


<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$registration_success = false;
$registration_error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password']; // No encryption
    $role = 'user';

    // Check if email already exists
    $email_check_sql = "SELECT email FROM users WHERE email='$email'";
    $email_check_result = $conn->query($email_check_sql);

    if ($email_check_result->num_rows > 0) {
        $registration_error = "Email already exists. Please use a different email.";
    } else {
        // Generate user ID
        $result = $conn->query("SELECT id FROM users ORDER BY id DESC LIMIT 1");
        if ($result->num_rows > 0) {
            $last_id = $result->fetch_assoc()['id'];
            $last_id_num = (int) substr($last_id, 3);
            $user_id = 'USR' . str_pad($last_id_num + 1, 3, '0', STR_PAD_LEFT);
        } else {
            $user_id = 'USR001';
        }

        $sql = "INSERT INTO users (id, first_name, last_name, phone, email, password, role) VALUES ('$user_id', '$first_name', '$last_name', '$phone', '$email', '$password', '$role')";

        if ($conn->query($sql) === TRUE) {
            $registration_success = true;
        } else {
            $registration_error = "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CarCarePro Register</title>
    <link rel="stylesheet" href="register.css">
    <script>
        <?php if ($registration_success): ?>
            alert("Registration successful! Redirecting to login page.");
            window.location.href = "login.php";
        <?php elseif (!empty($registration_error)): ?>
            alert("<?php echo $registration_error; ?>");
        <?php endif; ?>
    </script>
</head>
<body>
    <div class="container">
        <div class="register-section">
            <h1>CarCarePro</h1>
            <div class="buttons">
                <button class="login-btn" id="loginBtn">Log In</button>
                <button class="create-account-btn active">Create Account</button>
            </div>
            <h2>Join Now!</h2>
            <form class="register-form" method="POST" action="">
                <div class="name-fields">
                    <input type="text" name="first_name" placeholder="First Name" required>
                    <input type="text" name="last_name" placeholder="Last Name" required>
                </div>
                <input type="tel" name="phone" placeholder="+60 123456789" required>
                <input type="email" name="email" placeholder="example123@gmail.com" required>
                <input type="password" name="password" placeholder="Password" required>
                <input type="password" name="confirm_password" placeholder="Confirm Password" required>
                <button type="submit" class="submit-btn">&#10140;</button>
            </form>
        </div>
        <div class="image-section">
            <img src="car-login.jpg" alt="Car Image">
        </div>
    </div>
    <script src="register.js"></script>
</body>
</html>

<?php
// Database connection
$mysqli = new mysqli("localhost", "root", "", "carcarepro");

// Check connection
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

// Fetch data for car service details
$car_id = isset($_GET['car_id']) ? $_GET['car_id'] : 1; // Example car_id
$carQuery = "SELECT * FROM cars WHERE car_id = '$car_id'";
$carResult = $mysqli->query($carQuery);

if (!$carResult || $carResult->num_rows === 0) {
    header("Location: no_service_details.php");
    exit();
}

$car = $carResult->fetch_assoc();

$serviceQuery = "SELECT * FROM services WHERE car_id = '$car_id'";
$serviceResult = $mysqli->query($serviceQuery);

if (!$serviceResult) {
    echo "Error: " . $mysqli->error;
    exit();
}

$services = [];
while ($service = $serviceResult->fetch_assoc()) {
    $services[] = $service;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Service Details</title>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            height: 100%;
        }
        body {
            display: flex;
            flex-direction: column;
            background-color: #CCCCCC;
            background-image: url("background.jpg");
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
        .content {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .section {
            width: 80%;
            background-color: #f4f4f4;
            padding: 20px;
            margin: 20px 0;
            border-radius: 8px;
        }
        .section h2 {
            text-align: center;
        }
        .back-button {
            display: block;
            width: 100px;
            margin: 20px auto;
            padding: 10px;
            text-align: center;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        
    </style>
</head>
<body>
    <header>
        <?php include 'after-login-header.html'; ?>
    </header>
    <div class="content">
        <div class="section">
            <h2>Car Service Information</h2>
            <p>Car ID: <?php echo $car['car_id']; ?></p>
            <p>VIN: <?php echo $car['VIN']; ?></p>
            <p>Make: <?php echo $car['make']; ?></p>
            <p>Model: <?php echo $car['model']; ?></p>
            <p>Year: <?php echo $car['year']; ?></p>
        </div>

        <div class="section">
            <h2>Service Intervals</h2>
            <?php foreach ($services as $service): ?>
                <p>Service Type: <?php echo $service['service_type']; ?></p>
                <p>Last Changed: <?php echo $service['last_changed']; ?></p>
                <p>Scheduled Change: <?php echo $service['scheduled_change']; ?></p>
                <hr>
            <?php endforeach; ?>
        </div>

        <a href="CarManagement.php" class="back-button">Back</a>
    </div>
    <footer>
        <?php include 'footer.html'; ?>
    </footer>
</body>
</html>

<?php
$conn = new mysqli('localhost', 'root', '', 'carcarepro');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$make = $_POST['make'];
$model = $_POST['model'];
$year = $_POST['year'];
$mileage = $_POST['mileage'];
$VIN = $_POST['VIN'];

$sql = "INSERT INTO cars (make, model, year, mileage, VIN) VALUES ('$make', '$model', $year, $mileage, '$VIN')";
if ($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

$conn->close();
?>

<?php
session_start();

// Check if staff is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'staff') {
    header('Location: login.html');
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the current date
$current_date = date('Y-m-d');
$start_of_week = date('Y-m-d', strtotime('last Monday', strtotime($current_date)));
$start_of_month = date('Y-m-01');

// Fetch response statistics
$sql_today = "SELECT COUNT(*) as count FROM responses WHERE DATE(responded_at) = '$current_date'";
$sql_week = "SELECT COUNT(*) as count FROM responses WHERE DATE(responded_at) >= '$start_of_week'";
$sql_month = "SELECT COUNT(*) as count FROM responses WHERE DATE(responded_at) >= '$start_of_month'";

$result_today = $conn->query($sql_today);
$result_week = $conn->query($sql_week);
$result_month = $conn->query($sql_month);

$responses_today = $result_today->fetch_assoc()['count'];
$responses_week = $result_week->fetch_assoc()['count'];
$responses_month = $result_month->fetch_assoc()['count'];

// Fetch feedback status statistics
$sql_feedback_status = "SELECT 
                        COUNT(CASE WHEN status = 'Pending' THEN 1 END) as pending_count,
                        COUNT(CASE WHEN status = 'Responded' THEN 1 END) as responded_count
                        FROM feedback";
$result_feedback_status = $conn->query($sql_feedback_status);
$feedback_status = $result_feedback_status->fetch_assoc();

$pending_count = $feedback_status['pending_count'];
$responded_count = $feedback_status['responded_count'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analyze Feedback Trends</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            min-height: 100%;
            display: flex;
            flex-direction: column;
            background-color: #CCCCCC;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            background-attachment: fixed;
            background-image: url("background.jpg");
        }
        .container {
            flex: 1;
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }
        h1 {
            text-align: center;
        }
        .stats {
            display: flex;
            justify-content: space-around;
            margin-bottom: 20px;
        }
        .stats div {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .chart-container {
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <header>
        <?php include 'after-login-header-staff.html'; ?>
    </header>
    <div class="container">
        <h1>Feedback Analysis</h1>
        <div class="stats">
            <div>
                <h2>Responses Today</h2>
                <p><?php echo $responses_today; ?></p>
            </div>
            <div>
                <h2>Responses This Week</h2>
                <p><?php echo $responses_week; ?></p>
            </div>
            <div>
                <h2>Responses This Month</h2>
                <p><?php echo $responses_month; ?></p>
            </div>
        </div>
        <div class="chart-container">
            <canvas id="feedbackStatusChart"></canvas>
        </div>
    </div>
    <footer>
        <?php include 'footer.html'; ?>
    </footer>
    <script>
        const ctx = document.getElementById('feedbackStatusChart').getContext('2d');
        const feedbackStatusChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Pending', 'Responded'],
                datasets: [{
                    label: 'Feedback Status',
                    data: [<?php echo $pending_count; ?>, <?php echo $responded_count; ?>],
                    backgroundColor: ['#FF6384', '#36A2EB'],
                    borderColor: ['#FF6384', '#36A2EB'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Count'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Status'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(tooltipItem) {
                                return tooltipItem.raw;
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>

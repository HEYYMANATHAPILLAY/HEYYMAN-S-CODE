document.addEventListener('DOMContentLoaded', function() {
    let cars = [];
    
    function showAddCarForm() {
        document.getElementById('addCarForm').style.display = 'block';
    }
    
    function hideAddCarForm() {
        document.getElementById('addCarForm').style.display = 'none';
    }
    
    function addCar(event) {
        event.preventDefault();
        const make = document.getElementById('make').value;
        const model = document.getElementById('model').value;
        const year = document.getElementById('year').value;
        const mileage = document.getElementById('mileage').value;
        const VIN = document.getElementById('VIN').value;
        
        const car = {
            id: cars.length + 1,
            make: make,
            model: model,
            year: year,
            mileage: mileage,
            VIN: VIN
        };
        
        cars.push(car);
        displayCars();
        document.getElementById('addCar').reset();
        hideAddCarForm();
    }
    
    function displayCars() {
        const carList = document.getElementById('carList');
        carList.innerHTML = '';
        
        cars.forEach(car => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${car.make}</td>
                <td>${car.model}</td>
                <td>${car.year}</td>
                <td>${car.mileage}</td>
                <td>${car.VIN}</td>
                <td class="actions">
                    <button onclick="editCar(${car.id})"><span>Edit</span></button>
                    <button onclick="deleteCar(${car.id})"><span>Delete</span></button>
                </td>
            `;
            carList.appendChild(row);
        });
    }
    
    function editCar(id) {
        const car = cars.find(car => car.id === id);
        document.getElementById('make').value = car.make;
        document.getElementById('model').value = car.model;
        document.getElementById('year').value = car.year;
        document.getElementById('mileage').value = car.mileage;
        document.getElementById('VIN').value = car.VIN;
        showAddCarForm();
        
        document.getElementById('addCar').onsubmit = function(event) {
            event.preventDefault();
            car.make = document.getElementById('make').value;
            car.model = document.getElementById('model').value;
            car.year = document.getElementById('year').value;
            car.mileage = document.getElementById('mileage').value;
            car.VIN = document.getElementById('VIN').value;
            displayCars();
            document.getElementById('addCar').reset();
            hideAddCarForm();
            document.getElementById('addCar').onsubmit = addCar;
        };
    }
    
    function deleteCar(id) {
        cars = cars.filter(car => car.id !== id);
        displayCars();
    }
    
    window.showAddCarForm = showAddCarForm;
    window.addCar = addCar;
    window.editCar = editCar;
    window.deleteCar = deleteCar;
});

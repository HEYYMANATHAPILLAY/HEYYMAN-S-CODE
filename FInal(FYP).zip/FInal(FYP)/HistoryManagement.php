<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch user-specific data
function fetchData($conn, $sql) {
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    } else {
        $data = [];
    }
    return $data;
}

// Fetch user list for staff
if ($_SESSION['role'] == 'staff') {
    $sql_users = "SELECT id, email FROM users";
    $result_users = $conn->query($sql_users);
}

// Determine user ID to fetch data for
$user_id = isset($_GET['user_id']) ? $_GET['user_id'] : $_SESSION['user_id'];

// Fetch service history
$sql_service_history = "SELECT * FROM services WHERE car_id IN (SELECT car_id FROM cars WHERE user_id='$user_id')";
$service_history = fetchData($conn, $sql_service_history);

// Fetch payment history
$sql_payment_history = "SELECT * FROM payments WHERE user_id='$user_id'";
$payment_history = fetchData($conn, $sql_payment_history);

// Fetch appointment history
$sql_appointment_history = "SELECT a.*, sa.staff_id as assigned_staff_id 
                            FROM appointments a 
                            LEFT JOIN staff_assignments sa ON a.appointment_id = sa.appointment_id 
                            WHERE a.user_id='$user_id'";
$appointment_history = fetchData($conn, $sql_appointment_history);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>History Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            min-height: 100%;
            display: flex;
            flex-direction: column;
            background-color: #CCCCCC;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            background-attachment: fixed;
            background-image: url("background.jpg");
        }
        .container {
            width: 80%;
            margin: auto;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        label, select, button {
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
    </style>
</head>
<body>
    <header>
        <?php 
        if ($_SESSION['role'] == 'staff') {
            include 'after-login-header-staff.html';
        } else {
            include 'after-login-header.html';
        }
        ?>
    </header>
    <div class="container">
        <h1>History Management</h1>
        <?php if ($_SESSION['role'] == 'staff'): ?>
            <form method="GET" action="">
                <label for="user_id">Select User:</label>
                <select name="user_id" id="user_id" onchange="this.form.submit()">
                    <?php while($row = $result_users->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>" <?php if ($row['id'] == $user_id) echo 'selected'; ?>><?php echo $row['email']; ?></option>
                    <?php endwhile; ?>
                </select>
            </form>
        <?php endif; ?>
        
        <h2>Service History</h2>
        <table>
            <tr>
                <th>Service ID</th>
                <th>Car ID</th>
                <th>Service Type</th>
                <th>Last Changed</th>
                <th>Scheduled Change</th>
            </tr>
            <?php if (!empty($service_history)): ?>
                <?php foreach ($service_history as $service): ?>
                    <tr>
                        <td><?php echo $service['service_id']; ?></td>
                        <td><?php echo $service['car_id']; ?></td>
                        <td><?php echo $service['service_type']; ?></td>
                        <td><?php echo $service['last_changed']; ?></td>
                        <td><?php echo $service['scheduled_change']; ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5">No service history available.</td>
                </tr>
            <?php endif; ?>
        </table>

        <h2>Payment History</h2>
        <table>
            <tr>
                <th>Payment ID</th>
                <th>User ID</th>
                <th>Amount</th>
                <th>Payment Date</th>
                <th>Status</th>
            </tr>
            <?php if (!empty($payment_history)): ?>
                <?php foreach ($payment_history as $payment): ?>
                    <tr>
                        <td><?php echo $payment['id']; ?></td>
                        <td><?php echo $payment['user_id']; ?></td>
                        <td><?php echo $payment['amount']; ?></td>
                        <td><?php echo $payment['payment_date']; ?></td>
                        <td><?php echo $payment['status']; ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5">No payment history available.</td>
                </tr>
            <?php endif; ?>
        </table>

        <h2>Appointment History</h2>
        <table>
            <tr>
                <th>Appointment ID</th>
                <th>User ID</th>
                <th>Car ID</th>
                <th>Service Type</th>
                <th>Appointment Date</th>
                <th>Status</th>
                <th>Assigned Staff ID</th>
            </tr>
            <?php if (!empty($appointment_history)): ?>
                <?php foreach ($appointment_history as $appointment): ?>
                    <tr>
                        <td><?php echo $appointment['appointment_id']; ?></td>
                        <td><?php echo $appointment['user_id']; ?></td>
                        <td><?php echo $appointment['car_id']; ?></td>
                        <td><?php echo $appointment['service_type']; ?></td>
                        <td><?php echo $appointment['appointment_date']; ?></td>
                        <td><?php echo $appointment['status']; ?></td>
                        <td><?php echo $appointment['assigned_staff_id']; ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7">No appointment history available.</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
    <footer>
        <?php include 'footer.html'; ?>
    </footer>
</body>
</html>

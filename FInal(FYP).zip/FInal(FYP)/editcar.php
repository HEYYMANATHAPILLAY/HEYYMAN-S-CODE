<?php
$conn = new mysqli('localhost', 'root', '', 'carcarepro');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $make = $_POST['make'];
    $model = $_POST['model'];
    $year = $_POST['year'];
    $mileage = $_POST['mileage'];
    $VIN = $_POST['VIN'];

    $sql = "UPDATE cars SET make='$make', model='$model', year=$year, mileage=$mileage, VIN='$VIN' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        header('Location: CarManagement.php');
    } else {
        echo "Error updating record: " . $conn->error;
    }
} else {
    $id = $_GET['id'];
    $sql = "SELECT * FROM cars WHERE id=$id";
    $result = $conn->query($sql);
    $car = $result->fetch_assoc();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Car - CarCarePro</title>
    <link rel="stylesheet" href="CarManagement.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">
                <img src="logo.png" alt="CarCarePro Logo">
            </div>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
            <div class="auth-buttons">
                <a href="login.php" class="button">Log In</a>
                <a href="signup.php" class="button">Sign Up</a>
            </div>
        </nav>
    </header>
    <main>
        <section class="car-management">
            <h1>Edit Car</h1>
            <div class="car-form">
                <form action="editCar.php" method="POST">
                    <input type="hidden" name="id" value="<?php echo $car['id']; ?>">
                    <label for="make">Make:</label>
                    <input type="text" id="make" name="make" value="<?php echo $car['make']; ?>" required>
                    <label for="model">Model:</label>
                    <input type="text" id="model" name="model" value="<?php echo $car['model']; ?>" required>
                    <label for="year">Year:</label>
                    <input type="number" id="year" name="year" value="<?php echo $car['year']; ?>" required>
                    <label for="mileage">Mileage:</label>
                    <input type="number" id="mileage" name="mileage" value="<?php echo $car['mileage']; ?>" required>
                    <label for="VIN">VIN:</label>
                    <input type="text" id="VIN" name="VIN" value="<?php echo $car['VIN']; ?>" required>
                    <button type="submit"><span>Update Car</span></button>
                </form>
            </div>
        </section>
    </main>
    <footer>
        <?php include 'footer.php'; ?>
    </footer>
</body>
</html>

<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Ensure the alert ID is provided
if (!isset($_GET['id'])) {
    header('Location: alerts.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$alert_id = $_GET['id'];

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Verify the alert belongs to the logged-in user
$verify_sql = "SELECT * FROM alerts WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($verify_sql);
$stmt->bind_param("ss", $alert_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // If the alert exists and belongs to the user, delete it
    $delete_sql = "DELETE FROM alerts WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("ss", $alert_id, $user_id);
    $stmt->execute();
}

// Redirect back to the alerts page
header('Location: alerts.php');
exit();
?>

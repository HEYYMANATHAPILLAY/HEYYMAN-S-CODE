<?php
$conn = new mysqli('localhost', 'root', '', 'carcarepro');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET['id'];
$sql = "DELETE FROM cars WHERE id=$id";
if ($conn->query($sql) === TRUE) {
    header('Location: CarManagement.php');
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>

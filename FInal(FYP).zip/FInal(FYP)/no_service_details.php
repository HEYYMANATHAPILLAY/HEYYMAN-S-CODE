<?php
// Header and navigation
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>No Service History Found</title>
    <link rel="stylesheet" href="style.css"> <!-- Optional stylesheet -->
</head>
<body>
    <header>
        <nav>
            <!-- Your navigation menu here -->
        </nav>
    </header>
    <main>
        <h1>No Service History Found</h1>
        <p>We couldn't find any service history for the specified car ID and user ID.</p>
        <p>Please check your input and try again.</p>
        <p>You will be redirected back to Car Management in 2 seconds...</p>
    </main>
    <footer>
        <!-- Your footer content here -->
    </footer>
    <script>
        setTimeout(function() {
            window.location.href = 'CarManagement.php';
        }, 2000); // Redirect back to CarManagement.php after 2 seconds
    </script>
</body>
</html>
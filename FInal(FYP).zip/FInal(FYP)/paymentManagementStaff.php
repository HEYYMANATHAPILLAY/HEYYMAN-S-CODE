<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all users
$sql_users = "SELECT id, email FROM users";
$result_users = $conn->query($sql_users);

$selected_user_id = null;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['process_refund'])) {
        $payment_id = $_POST['payment_id'];
        $refund_amount = $_POST['refund_amount'];

        $sql = "INSERT INTO Refunds (payment_id, refund_amount, refund_date, status) 
                VALUES ('$payment_id', '$refund_amount', NOW(), 'Processed')";
        $conn->query($sql);

        $sql_update_payment = "UPDATE Payments SET status='Refunded' WHERE id='$payment_id'";
        $conn->query($sql_update_payment);
    } elseif (isset($_POST['search_user'])) {
        $selected_user_id = $_POST['user_id'];
    }
}

// Fetch payments for selected user
$sql_payments = "SELECT p.*, u.email, m.method_name FROM Payments p 
                 JOIN users u ON p.user_id = u.id 
                 JOIN PaymentMethods m ON p.method_id = m.id";
if ($selected_user_id) {
    $sql_payments .= " WHERE p.user_id = '$selected_user_id'";
}
$result_payments = $conn->query($sql_payments);

// Fetch refunds for selected user
$sql_refunds = "SELECT r.*, p.amount FROM Refunds r 
                JOIN Payments p ON r.payment_id = p.id";
if ($selected_user_id) {
    $sql_refunds .= " WHERE p.user_id = '$selected_user_id'";
}
$result_refunds = $conn->query($sql_refunds);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Payment Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background-color: #CCCCCC;
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
            background-image: url("background.jpg");
        }

        main {
            flex: 1;
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
            background-color: rgba(255, 255, 255, 0.8); /* Less transparent background for table cells */
        }

        th {
            background-color: rgba(240, 240, 240, 0.9); /* Less transparent background for table headers */
        }

        tr:nth-child(even) td {
            background-color: rgba(245, 245, 245, 0.8); /* Slightly different background for even rows */
        }

        h1, h2 {
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        form label {
            margin: 5px 0;
        }

        form input, form select {
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .refund-button, .search-button {
            padding: 17px 40px;
            border-radius: 50px;
            cursor: pointer;
            border: 0;
            background-color: white;
            box-shadow: rgb(0 0 0 / 5%) 0 0 8px;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            font-size: 15px;
            transition: all 0.5s ease;
            align-self: start;
        }

        .refund-button:hover, .search-button:hover {
            letter-spacing: 3px;
            background-color: hsl(261deg 80% 48%);
            color: hsl(0, 0%, 100%);
            box-shadow: rgb(93 24 220) 0px 7px 29px 0px;
        }

        .refund-button:active, .search-button:active {
            letter-spacing: 3px;
            background-color: hsl(261deg 80% 48%);
            color: hsl(0, 0%, 100%);
            box-shadow: rgb(93 24 220) 0px 0px 0px 0px;
            transform: translateY(10px);
            transition: 100ms;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .section-title {
            margin-top: 40px;
            font-size: 1.5em;
        }

        .button {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #e8e8e8;
            background-color: #212121;
            width: 70px;
            height: 70px;
            font-size: 24px;
            text-transform: uppercase;
            border: 2px solid #212121;
            border-radius: 50%;
            transition: all 0.6s cubic-bezier(0.23, 1, 0.320, 1);
            box-shadow: 5px 5px 2px rgba(0, 0, 0, 0.15),
                        2px 2px 2px rgba(0, 0, 0, 0.1),
                        -3px -3px 2px rgba(255, 255, 255, 0.05),
                        -2px -2px 1px rgba(255, 255, 255, 0.05);
            overflow: hidden;
            cursor: pointer;
        }

        .button .span {
            position: relative;
            z-index: 2;
            transition: all 0.6s cubic-bezier(0.23, 1, 0.320, 1);
        }

        .button::before {
            content: "";
            position: absolute;
            background-color: #e8e8e8;
            width: 150%;
            height: 150%;
            left: 0%;
            bottom: 0%;
            transform: translate(-100%, 100%) rotate(45deg);
            border-radius: 15px;
        }

        .button:hover::before {
            animation: shakeBack 0.6s forwards 0.6s;
        }

        .button:hover .span {
            scale: 1.2;
        }

        .button:hover {
            box-shadow: none;
        }

        .button:active {
            scale: 0.95;
        }

        @keyframes shakeBack {
            0% {
                transform: translate(-100%, 100%) rotate(45deg);
            }

            50% {
                transform: translate(15%, -15%) rotate(45deg);
            }

            100% {
                transform: translate(-10%, 10%) rotate(45deg);
            }
        }
    </style>
</head>
<body>
    <header>
        <?php include 'after-login-header-staff.html'; ?>
    </header>
    <main>
        <div class="container">
            <section>
                <h1>Payment Records</h1>

                <form method="POST" action="">
                    <label for="user_id">Select User:</label>
                    <select id="user_id" name="user_id" required>
                        <option value="">Select a user</option>
                        <?php while ($row = $result_users->fetch_assoc()): ?>
                            <option value="<?php echo $row['id']; ?>" <?php if ($row['id'] == $selected_user_id) echo 'selected'; ?>>
                                <?php echo $row['email']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                    <button type="submit" name="search_user" class="search-button button">🔎</button>
                    <br>
                </form>

                <table>
                    <thead>
                        <tr>
                            <th>Payment ID</th>
                            <th>User</th>
                            <th>Method</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $result_payments->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo $row['email']; ?></td>
                                <td><?php echo $row['method_name']; ?></td>
                                <td><?php echo $row['amount']; ?></td>
                                <td><?php echo $row['payment_date']; ?></td>
                                <td><?php echo $row['status']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

                <h2 class="section-title">Process Refund</h2>
                <form method="POST" action="">
                    <label for="payment_id">Payment ID:</label>
                    <input type="text" id="payment_id" name="payment_id" required>
                    <label for="refund_amount">Refund Amount:</label>
                    <input type="text" id="refund_amount" name="refund_amount" required>
                    <button type="submit" name="process_refund" class="refund-button">Process Refund</button>
                </form>

                <h1 class="section-title">Refund Records</h1>
                <table>
                    <thead>
                        <tr>
                            <th>Refund ID</th>
                            <th>Payment ID</th>
                            <th>Refund Amount</th>
                            <th>Refund Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $result_refunds->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo $row['payment_id']; ?></td>
                                <td><?php echo $row['refund_amount']; ?></td>
                                <td><?php echo $row['refund_date']; ?></td>
                                <td><?php echo $row['status']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </section>
        </div>
    </main>
    <footer>
        <?php include 'footer.html'; ?>
    </footer>
</body>
</html>

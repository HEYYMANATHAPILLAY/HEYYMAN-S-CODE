<?php
// Start session for user authentication
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Redirect to dashboard.php if role is not staff or user
if ($_SESSION['role'] !== 'staff' && $_SESSION['role'] !== 'user') {
    header('Location: dashboard.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Database connection
$mysqli = new mysqli("localhost", "root", "", "carcarepro");

// Check connection
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

// Fetch data for car service details
$car_id = isset($_GET['car_id']) ? $_GET['car_id'] : 1; // Example car_id
$carQuery = "SELECT * FROM cars WHERE car_id = '$car_id'";
$carResult = $mysqli->query($carQuery);

if (!$carResult || $carResult->num_rows === 0) {
    header("Location: no_service_details.php");
    exit();
}

$car = $carResult->fetch_assoc();

$serviceQuery = "SELECT * FROM services WHERE car_id = '$car_id'";
$serviceResult = $mysqli->query($serviceQuery);

if (!$serviceResult) {
    echo "Error: " . $mysqli->error;
    exit();
}

$services = [];
while ($service = $serviceResult->fetch_assoc()) {
    $services[] = $service;
}

// Handle POST requests for adding, editing, and deleting services
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    if ($action === 'add') {
        $service_type = $_POST['service_type'];
        $last_changed = $_POST['last_changed'];
        $scheduled_change = $_POST['scheduled_change'];

        $sql = "INSERT INTO services (car_id, service_type, last_changed, scheduled_change) 
                VALUES ('$car_id', '$service_type', '$last_changed', '$scheduled_change')";
        if ($mysqli->query($sql) === TRUE) {
            echo "Service added successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $mysqli->error;
        }
    }

    if ($action === 'edit') {
        $service_id = $_POST['service_id'];
        $service_type = $_POST['service_type'];
        $last_changed = $_POST['last_changed'];
        $scheduled_change = $_POST['scheduled_change'];

        $sql = "UPDATE services SET service_type='$service_type', last_changed='$last_changed', scheduled_change='$scheduled_change' 
                WHERE service_id='$service_id'";
        if ($mysqli->query($sql) === TRUE) {
            echo "Service updated successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $mysqli->error;
        }
    }

    if ($action === 'delete') {
        $service_id = $_POST['service_id'];

        $sql = "DELETE FROM services WHERE service_id='$service_id'";
        if ($mysqli->query($sql) === TRUE) {
            echo "Service deleted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $mysqli->error;
        }
    }
    header("Location: serviceDetails.php?car_id=$car_id");
    exit();
}

$mysqli->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Service Details</title>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            height: 100%;
        }
        body {
            display: flex;
            flex-direction: column;
            background-color: #CCCCCC;
            background-image: url("background.jpg");
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
        .content {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .section {
            width: 80%;
            background-color: #f4f4f4;
            padding: 20px;
            margin: 20px 0;
            border-radius: 8px;
        }
        .section h2 {
            text-align: center;
        }
        .back-button {
            display: block;
            width: 100px;
            margin: 20px auto;
            padding: 10px;
            text-align: center;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .action-button {
            margin: 0 5px;
            padding: 5px 10px;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .edit-button {
            background-color: #4CAF50; /* Green */
        }
        .delete-button {
            background-color: #f44336; /* Red */
        }
        .add-service button {
            padding: 10px 20px;
            background-color: #007BFF; /* Blue */
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-bottom: 20px;
        }
        .add-service button:hover {
            background-color: #0056b3; /* Darker blue */
        }
        .car-form {
            display: none;
        }
        .car-form.active {
            display: block;
        }
    </style>
</head>
<body>
    <header>
        <?php 
        if ($_SESSION['role'] == 'staff') {
            include 'after-login-header-staff.html';
        } else {
            include 'after-login-header.html';
        }
        ?>
    </header>
    <div class="content">
        <div class="section">
            <h2>Car Service Information</h2>
            <p>Car ID: <?php echo $car['car_id']; ?></p>
            <p>VIN: <?php echo $car['VIN']; ?></p>
            <p>Make: <?php echo $car['make']; ?></p>
            <p>Model: <?php echo $car['model']; ?></p>
            <p>Year: <?php echo $car['year']; ?></p>
        </div>

        <div class="section">
            <h2>Service Intervals</h2>
            <div class="add-service">
                <button onclick="showAddServiceForm()">Add Service</button>
            </div>
            <div class="car-form" id="addServiceForm">
                <h2>Add Service</h2>
                <form id="addService" method="POST">
                    <label for="service_type">Service Type:</label>
                    <input type="text" id="service_type" name="service_type" required>
                    <label for="last_changed">Last Changed:</label>
                    <input type="date" id="last_changed" name="last_changed" required>
                    <label for="scheduled_change">Scheduled Change:</label>
                    <input type="date" id="scheduled_change" name="scheduled_change" required>
                    <input type="hidden" name="action" value="add">
                    <button type="submit">Add Service</button>
                </form>
            </div>
            <div class="car-form" id="editServiceForm">
                <h2>Edit Service</h2>
                <form id="editService" method="POST">
                    <input type="hidden" id="editServiceId" name="service_id">
                    <label for="editServiceType">Service Type:</label>
                    <input type="text" id="editServiceType" name="service_type" required>
                    <label for="editLastChanged">Last Changed:</label>
                    <input type="date" id="editLastChanged" name="last_changed" required>
                    <label for="editScheduledChange">Scheduled Change:</label>
                    <input type="date" id="editScheduledChange" name="scheduled_change" required>
                    <input type="hidden" name="action" value="edit">
                    <button type="submit">Save Changes</button>
                </form>
            </div>
            <?php foreach ($services as $service): ?>
                <p>Service Type: <?php echo $service['service_type']; ?></p>
                <p>Last Changed: <?php echo $service['last_changed']; ?></p>
                <p>Scheduled Change: <?php echo $service['scheduled_change']; ?></p>
                <button class="action-button edit-button" onclick="showEditServiceForm(<?php echo htmlspecialchars(json_encode($service)); ?>)">Edit</button>
                <form method="POST" action="serviceDetails.php?car_id=<?php echo $car_id; ?>" style="display:inline-block;">
                    <input type="hidden" name="service_id" value="<?php echo $service['service_id']; ?>">
                    <input type="hidden" name="action" value="delete">
                    <button type="submit" class="action-button delete-button">Delete</button>
                </form>
                <hr>
            <?php endforeach; ?>
        </div>

        <a href="CarManagementStaff.php" class="back-button">Back</a>
    </div>
    <footer>
        <?php include 'footer.html'; ?>
    </footer>
    <script>
        function showAddServiceForm() {
            document.getElementById('addServiceForm').classList.add('active');
            document.getElementById('editServiceForm').classList.remove('active');
        }

        function showEditServiceForm(service) {
            document.getElementById('editServiceForm').classList.add('active');
            document.getElementById('addServiceForm').classList.remove('active');

            document.getElementById('editServiceId').value = service.service_id;
            document.getElementById('editServiceType').value = service.service_type;
            document.getElementById('editLastChanged').value = service.last_changed;
            document.getElementById('editScheduledChange').value = service.scheduled_change;
        }
    </script>
</body>
</html>

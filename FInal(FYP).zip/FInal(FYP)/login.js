function validateForm() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('error-message');

    // Dummy check for email and password (replace with actual validation logic)
    if (email !== 'example123@gmail.com' || password !== 'password') {
        errorMessage.textContent = 'Incorrect username or password';
        errorMessage.style.display = 'block';
        return false; // Prevent form submission
    }
    return true; // Allow form submission
}

// Add event listener to the create account button
document.getElementById('createAccountBtn').addEventListener('click', function() {
    window.location.href = 'register.php';
});


<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Fetch user information
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

$role = $user['role']; // Assuming 'role' column exists in the users table

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $info = $_POST['info'];

    $imageFile = $_FILES['profile_picture'];
    $imageFileName = ''; // Initialize with an empty string

    // Check for email uniqueness, excluding the current user's email
    $email_check_stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
    $email_check_stmt->bind_param("ss", $email, $user_id);
    $email_check_stmt->execute();
    $email_check_stmt->store_result();

    if ($email_check_stmt->num_rows > 0) {
        $error = "Email address is already in use by another account.";
    } else {
        // Handle file upload
        if ($imageFile['name']) {
            $target_dir = "assets/images/users/"; // Change the upload directory
            $original_file_name = pathinfo($imageFile["name"], PATHINFO_FILENAME);
            $imageFileType = strtolower(pathinfo($imageFile["name"], PATHINFO_EXTENSION));
            $new_file_name = $original_file_name . "_" . time() . "." . $imageFileType;
            $target_file = $target_dir . $new_file_name;
            $check = getimagesize($imageFile["tmp_name"]);

            if ($check === false) {
                $error = "File is not an image.";
            } elseif ($imageFile["size"] > 500000) {
                $error = "Sorry, your file is too large.";
            } elseif (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
                $error = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            } else {
                if (move_uploaded_file($imageFile["tmp_name"], $target_file)) {
                    $imageFileName = $new_file_name;
                } else {
                    $error = "Sorry, there was an error uploading your file.";
                }
            }
        }

        if (!$error) {
            // Fetch current user data
            $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->bind_param("s", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $current_user = $result->fetch_assoc();
            $stmt->close();

            // Determine if a new image was uploaded or not
            $imageToUpdate = $imageFileName ? $imageFileName : $current_user['ImageFile'];

            // Update user data
            $stmt = $conn->prepare("UPDATE users SET first_name = ?, last_name = ?, phone = ?, info = ?, ImageFile = ? WHERE id = ?");
            $stmt->bind_param("ssssss", $first_name, $last_name, $phone, $info, $imageToUpdate, $user_id);

            if ($stmt->execute()) {
                // Update email separately if it has changed
                if ($email != $current_user['email']) {
                    $stmt2 = $conn->prepare("UPDATE users SET email = ? WHERE id = ?");
                    $stmt2->bind_param("ss", $email, $user_id);
                    $stmt2->execute();
                    $stmt2->close();
                }
                $success = "Profile updated successfully.";
            } else {
                $error = "Error updating profile: " . $conn->error;
            }
            $stmt->close();
        }
    }
    $email_check_stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            background-attachment: fixed;
            background-image: url("background.jpg");
        }
        .content {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .profile-container {
            width: 50%;
            background-color: #fff;
            padding: 20px;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .profile-container h1 {
            text-align: center;
            color: #333;
        }
        .profile-container form {
            display: flex;
            flex-direction: column;
        }
        .profile-container label {
            margin-top: 10px;
            font-weight: bold;
        }
        .profile-container input[type="text"],
        .profile-container input[type="email"],
        .profile-container input[type="file"] {
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .profile-container button {
            padding: 10px;
            margin-top: 20px;
            border-radius: 5px;
            border: none;
            background-color: #007BFF;
            color: #fff;
            font-weight: bold;
            cursor: pointer;
        }
        .profile-container button:hover {
            background-color: #0056b3;
        }
        .profile-container .error {
            color: red;
        }
        .profile-container .success {
            color: green;
        }
        .profile-container .profile-picture {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <header>
        <?php 
        if ($role === 'staff') {
            include 'after-login-header-staff.html';
        } else {
            include 'after-login-header.html';
        }
        ?>
    </header>
    <div class="content">
        <div class="profile-container">
            <h1>Edit Profile</h1>
            <?php if ($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="success"><?php echo $success; ?></div>
            <?php endif; ?>
            <form method="POST" action="" enctype="multipart/form-data">
                <label for="first_name">First Name</label>
                <input type="text" name="first_name" id="first_name" value="<?php echo htmlspecialchars($user['first_name']); ?>" required>

                <label for="last_name">Last Name</label>
                <input type="text" name="last_name" id="last_name" value="<?php echo htmlspecialchars($user['last_name']); ?>" required>

                <label for="phone">Phone</label>
                <input type="text" name="phone" id="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" required>

                <label for="email">Email</label>
                <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>

                <label for="info">Info</label>
                <input type="text" name="info" id="info" value="<?php echo htmlspecialchars($user['info']); ?>">

                <label for="profile_picture">Profile Picture</label>
                <input type="file" name="profile_picture" id="profile_picture">
                <?php if ($user['ImageFile']): ?>
                    <img src="assets/images/users/<?php echo htmlspecialchars($user['ImageFile']); ?>" alt="Profile Picture" class="profile-picture">
                <?php endif; ?>

                <button type="submit">Save</button>
            </form>
        </div>
    </div>
    <footer>
        <?php include 'footer.html'; ?>
    </footer>
</body>
</html>

<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$feedback_submitted = false;
$feedback_error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $feedback = $_POST['feedback'];
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : NULL;
    $guest_name = $_POST['guest_name'] ?? '';
    $guest_email = $_POST['guest_email'] ?? '';

    $sql = "INSERT INTO feedback (user_id, feedback, guest_name, guest_email) VALUES ('$user_id', '$feedback', '$guest_name', '$guest_email')";

    if ($conn->query($sql) === TRUE) {
        $feedback_submitted = true;
    } else {
        $feedback_error = "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Feedback - CarCarePro</title>
    <link rel="stylesheet" href="feedback.css">
</head>
<body>
    <header>
    <?php
          include 'after-login-header.html';
        ?>
    </header>
    <main>
        <section class="feedback-section">
            <h1>Customer Feedback/Contact Us</h1>
            <?php if ($feedback_submitted): ?>
                <p class="success-message">Thank you for your feedback!</p>
            <?php elseif (!empty($feedback_error)): ?>
                <p class="error-message"><?php echo $feedback_error; ?></p>
            <?php endif; ?>
            <form id="feedbackForm" method="POST" action="">
                <?php if (!isset($_SESSION['user_id'])): ?>
                    <label for="guest_name">Name:</label>
                    <input type="text" id="guest_name" name="guest_name" required>
                    <label for="guest_email">Email:</label>
                    <input type="email" id="guest_email" name="guest_email" required>
                <?php endif; ?>
                <label for="feedback">Feedback:</label>
                <textarea id="feedback" name="feedback" required></textarea>
                <button type="submit">Submit</button>
            </form>
            <br>
            <form id="viewResponsesForm" method="GET" action="viewFeedback.php">
                <button type="submit" class="view-responses-button">View Responses</button>
            </form>
        </section>
    </main>
    <footer>
    <?php
          include 'footer.html';
        ?>
    </footer>
</body>
</html>

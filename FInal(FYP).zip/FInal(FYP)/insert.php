<?php
require_once 'database_connect.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
$conn = OpenCon();

if(isset($_POST['submit']))
{
    $targetDir = "assets/images/users/";

    if(empty($_POST['firstName']) || empty($_POST['lastName']) || empty($_POST['userInfo']) || empty($_POST['userPhone']) || empty($_POST['email']))
    {
        echo "Please fill in all required fields.";
    }
    else
    {  
        $firstName = $_POST['firstName'];
        $lastName = $_POST['lastName'];
        $userInfo = $_POST['userInfo'];
        $userPhone = $_POST['userPhone'];
        $email = $_POST['email'];
        $status = $_POST['status'];
        $role = $_POST['role'];
     
        // Start transaction
        $conn->begin_transaction();

        // Lock the tables to prevent race conditions
        $conn->query("LOCK TABLES users WRITE, image WRITE");

        // Generate a unique ID manually for users table
        $result = $conn->query("SELECT MAX(id) AS max_id FROM users WHERE id LIKE 'USR%'");
        $row = $result->fetch_assoc();
        $maxId = $row['max_id'];

        // Extract the numeric part of the ID and increment it
        if($maxId){
            $numericPart = intval(substr($maxId, 3)) + 1;
        } else {
            $numericPart = 1;
        }
        $newId = 'USR' . str_pad($numericPart, 3, '0', STR_PAD_LEFT);

        // Handle image upload
        if(isset($_FILES['uploadfile']) && $_FILES['uploadfile']['error'] == 0){
            $fileName = basename($_FILES['uploadfile']['name']);
            $targetPath = $targetDir . $fileName;
           
            if(move_uploaded_file($_FILES["uploadfile"]["tmp_name"], $targetPath))
            {
                // Insert image data into image table
                $sql = "INSERT INTO image (filename, filepath) VALUES ('$fileName', '$targetPath')";
            
                if($conn->query($sql) === TRUE)
                {
                    echo "<script>alert('File uploaded and saved to DB');</script>";

                    // Insert user data into users table
                    $insertsql = "INSERT INTO users (id, first_name, last_name, phone, email, info, password, status, ImageFile) 
                                  VALUES ('$newId', '$firstName', '$lastName', '$userPhone', '$email', '$userInfo', 'abc123', '$status', '$fileName')";

                    if($conn->query($insertsql) === TRUE)
                    {
                        // Commit the transaction
                        $conn->commit();
                        header("location:usermgt.php");
                        exit();
                    }
                    else
                    {
                        echo "<script>alert('Error: Could not insert user data');</script>";
                        // Rollback the transaction if insertion fails
                        $conn->rollback();
                    }
                }
                else {
                    echo "Error: ".$sql."<br />" . $conn->error;
                }
            }
            else {
                echo "Error Moving the file";
            }
        }
        else {
            echo "File not uploaded";
        }

        // Unlock the tables
        $conn->query("UNLOCK TABLES");
    }
}
else
{
    header("location:cust_info.php");
    exit();
}

$conn->close();
?>
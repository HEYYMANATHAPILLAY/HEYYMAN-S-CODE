<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to generate the next car ID
function generateCarID($conn) {
    $sql = "SELECT car_id FROM cars ORDER BY car_id DESC LIMIT 1";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $lastID = $row['car_id'];
        $number = intval(str_replace('CR_', '', $lastID)) + 1;
        return 'CR_' . $number;
    } else {
        return 'CR_1';
    }
}

// Handle adding a car
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $car_id = generateCarID($conn);
    $make = $_POST['make'];
    $model = $_POST['model'];
    $year = $_POST['year'];
    $mileage = $_POST['mileage'];
    $vin = $_POST['vin'];

    $sql = "INSERT INTO cars (car_id, user_id, make, model, year, mileage, VIN) VALUES ('$car_id', '$user_id', '$make', '$model', $year, $mileage, '$vin')";
    if ($conn->query($sql) === TRUE) {
        echo "New car added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Handle deleting a car
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $car_id = $_POST['car_id'];

    $sql = "DELETE FROM cars WHERE car_id = '$car_id' AND user_id = '$user_id'";
    if ($conn->query($sql) === TRUE) {
        echo "Car deleted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Handle editing a car
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $car_id = $_POST['car_id'];
    $make = $_POST['make'];
    $model = $_POST['model'];
    $year = $_POST['year'];
    $mileage = $_POST['mileage'];
    $vin = $_POST['vin'];

    $sql = "UPDATE cars SET make = '$make', model = '$model', year = $year, mileage = $mileage, VIN = '$vin' WHERE car_id = '$car_id' AND user_id = '$user_id'";
    if ($conn->query($sql) === TRUE) {
        echo "Car updated successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Fetch cars data for the logged-in user
$sql = "SELECT * FROM cars WHERE user_id = '$user_id'";
$result = $conn->query($sql);
$cars = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $cars[] = $row;
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Management - CarCarePro</title>
    <link rel="stylesheet" href="CarManagement.css">
    <style>
        .action-button {
            margin: 0 5px;
            padding: 5px 10px;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .edit-button {
            background-color: #4CAF50; /* Green */
        }

        .delete-button {
            background-color: #f44336; /* Red */
        }

        .service-button {
            background-color: #008CBA; /* Blue */
        }

        .car-form {
            display: none;
        }

        .car-form.active {
            display: block;
        }
    </style>
</head>
<body>
    <header>
    <?php
          include 'after-login-header.html';
        ?>
    </header>
    <main>
        <section class="car-management">
            <h1>Car Management</h1>
            <div class="add-car">
                <button onclick="showAddCarForm()"><span>Add Car</span></button>
            </div>
            <br>
            <div class="car-form" id="addCarForm">
                <h2>Add Car</h2>
                <form id="addCar" onsubmit="addCar(event)">
                    <label for="make">Make:</label>
                    <input type="text" id="make" name="make" required>
                    <label for="model">Model:</label>
                    <input type="text" id="model" name="model" required>
                    <label for="year">Year:</label>
                    <input type="number" id="year" name="year" required>
                    <label for="mileage">Mileage:</label>
                    <input type="number" id="mileage" name="mileage" required>
                    <label for="vin">VIN:</label>
                    <input type="text" id="vin" name="vin" required>
                    <input type="hidden" name="action" value="add">
                    <button type="submit">Add Car</button>
                </form>
            </div>
            <br>
            <div class="car-form" id="editCarForm">
                <h2>Edit Car</h2>
                <form id="editCar" onsubmit="saveEditCar(event)">
                    <input type="hidden" id="editCarId" name="car_id">
                    <label for="editMake">Make:</label>
                    <input type="text" id="editMake" name="make" required>
                    <label for="editModel">Model:</label>
                    <input type="text" id="editModel" name="model" required>
                    <label for="editYear">Year:</label>
                    <input type="number" id="editYear" name="year" required>
                    <label for="editMileage">Mileage:</label>
                    <input type="number" id="editMileage" name="mileage" required>
                    <label for="editVin">VIN:</label>
                    <input type="text" id="editVin" name="vin" required>
                    <input type="hidden" name="action" value="edit">
                    <button type="submit">Save Changes</button>
                </form>
            </div>
            <br>
            <div class="car-list">
                <h2>Cars</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Car ID</th>
                            <th>Make</th>
                            <th>Model</th>
                            <th>Year</th>
                            <th>Mileage</th>
                            <th>VIN</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cars as $car): ?>
                            <tr>
                                <td><?= $car['car_id'] ?></td>
                                <td><?= $car['make'] ?></td>
                                <td><?= $car['model'] ?></td>
                                <td><?= $car['year'] ?></td>
                                <td><?= $car['mileage'] ?></td>
                                <td><?= $car['VIN'] ?></td>
                                <td>
                                    <button class="action-button edit-button" onclick="editCar('<?= $car['car_id'] ?>', '<?= $car['make'] ?>', '<?= $car['model'] ?>', <?= $car['year'] ?>, <?= $car['mileage'] ?>, '<?= $car['VIN'] ?>')">Edit</button>
                                    <button class="action-button delete-button" onclick="deleteCar('<?= $car['car_id'] ?>')">Delete</button>
                                    <form action="serviceDetails.php" method="GET" style="display:inline;">
                                        <input type="hidden" name="car_id" value="<?= $car['car_id'] ?>">
                                        <button type="submit" class="action-button service-button">Service</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
    <footer>
    <?php
          include 'footer.html';
        ?>
    </footer>

    <script>
        function showAddCarForm() {
            document.getElementById('addCarForm').classList.add('active');
            document.getElementById('editCarForm').classList.remove('active');
        }

        function addCar(event) {
            event.preventDefault();
            const form = document.getElementById('addCar');
            const formData = new FormData(form);
            fetch('CarManagement.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                alert(data);
                location.reload();
            });
        }

        function editCar(car_id, make, model, year, mileage, vin) {
            document.getElementById('editCarForm').classList.add('active');
            document.getElementById('addCarForm').classList.remove('active');
            document.getElementById('editCarId').value = car_id;
            document.getElementById('editMake').value = make;
            document.getElementById('editModel').value = model;
            document.getElementById('editYear').value = year;
            document.getElementById('editMileage').value = mileage;
            document.getElementById('editVin').value = vin;
        }

        function saveEditCar(event) {
            event.preventDefault();
            const form = document.getElementById('editCar');
            const formData = new FormData(form);
            fetch('CarManagement.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                alert(data);
                location.reload();
            });
        }

        function deleteCar(car_id) {
            if (confirm('Are you sure you want to delete this car?')) {
                const formData = new FormData();
                formData.append('action', 'delete');
                formData.append('car_id', car_id);
                fetch('CarManagement.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.text())
                .then(data => {
                    alert(data);
                    location.reload();
                });
            }
        }
    </script>
</body>
</html>

<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'] ?? NULL;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle different actions like add payment method, make payment, etc.
    if (isset($_POST['add_method'])) {
        $method_name = $_POST['method_name'];
        $card_number = $_POST['card_number'];
        $expiry_date = $_POST['expiry_date'];
        $cvv = $_POST['cvv'];
        
        $sql = "INSERT INTO PaymentMethods (user_id, method_name, card_number, expiry_date, cvv) 
                VALUES ('$user_id', '$method_name', '$card_number', '$expiry_date', '$cvv')";
        $conn->query($sql);
    }
    
    if (isset($_POST['make_payment'])) {
        $method_id = $_POST['method_id'];
        $amount = $_POST['amount'];
        
        $sql = "INSERT INTO Payments (user_id, method_id, amount, payment_date, status) 
                VALUES ('$user_id', '$method_id', '$amount', NOW(), 'Completed')";
        $conn->query($sql);
    }
}

// Fetch payment methods
$sql_methods = "SELECT * FROM PaymentMethods WHERE user_id='$user_id'";
$result_methods = $conn->query($sql_methods);

// Fetch payment history
$sql_payments = "SELECT p.*, m.method_name FROM Payments p JOIN PaymentMethods m ON p.method_id = m.id WHERE p.user_id='$user_id'";
$result_payments = $conn->query($sql_payments);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Payment Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            min-height: 100%;
            display: flex;
            flex-direction: column;
            background-color: #CCCCCC;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            background-attachment: fixed;
            background-image: url("background.jpg");
        }

        main {
            flex: 1;
            padding: 20px;
        }

        h1, h2 {
            text-align: center;
            color: #333;
        }

        form {
            max-width: 600px;
            margin: 0 auto 20px;
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input, select, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .payment-button {
            text-decoration: none;
            position: relative;
            border: none;
            font-size: 14px;
            font-family: inherit;
            cursor: pointer;
            color: #fff;
            width: 100%;
            height: 3em;
            line-height: 2em;
            text-align: center;
            background: linear-gradient(90deg, #03a9f4, #f441a5, #ffeb3b, #03a9f4);
            background-size: 300%;
            border-radius: 30px;
            z-index: 1;
        }

        .payment-button:hover {
            animation: ani 8s linear infinite;
            border: none;
        }

        @keyframes ani {
            0% {
                background-position: 0%;
            }

            100% {
                background-position: 400%;
            }
        }

        .payment-button:before {
            content: "";
            position: absolute;
            top: -5px;
            left: -5px;
            right: -5px;
            bottom: -5px;
            z-index: -1;
            background: linear-gradient(90deg, #03a9f4, #f441a5, #ffeb3b, #03a9f4);
            background-size: 400%;
            border-radius: 35px;
            transition: 1s;
        }

        .payment-button:hover::before {
            filter: blur(20px);
        }

        .payment-button:active {
            background: linear-gradient(32deg, #03a9f4, #f441a5, #ffeb3b, #03a9f4);
        }

        .loading {
            display: none;
            margin-top: 10px;
            text-align: center;
            color: #f441a5;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }

        th {
            background-color: #f4f4f4;
            font-weight: bold;
        }

        tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
    <script>
        function showLoading() {
            document.getElementById('loading').style.display = 'block';
            setTimeout(function() {
                document.getElementById('paymentForm').submit();
            }, 5000);
        }
    </script>
</head>
<body>
    <header>
        <?php include 'after-login-header.html'; ?>
    </header>
    <main>
        <section>
            <h1>Manage Payments</h1>
            <h2>Add Payment Method</h2>
            <form method="POST" action="">
                <label for="method_name">Method Name:</label>
                <input type="text" id="method_name" name="method_name" required>
                <label for="card_number">Card Number:</label>
                <input type="text" id="card_number" name="card_number" required>
                <label for="expiry_date">Expiry Date:</label>
                <input type="date" id="expiry_date" name="expiry_date" required>
                <label for="cvv">CVV:</label>
                <input type="text" id="cvv" name="cvv" required>
                <button class="payment-button" type="submit" name="add_method">Add Method</button>
            </form>

            <h2>Make Payment</h2>
            <form method="POST" action="" id="paymentForm">
                <label for="method_id">Payment Method:</label>
                <select id="method_id" name="method_id" required>
                    <?php while($row = $result_methods->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>"><?php echo $row['method_name']; ?></option>
                    <?php endwhile; ?>
                </select>
                <label for="amount">Amount:</label>
                <input type="text" id="amount" name="amount" required>
                <button class="payment-button" type="submit" name="make_payment" onclick="showLoading()">Make Payment</button>
                <div id="loading" class="loading">Processing payment, please wait...</div>
            </form>

            <h2>Payment History</h2>
            <table>
                <thead>
                    <tr>
                        <th>Payment ID</th>
                        <th>Method</th>
                        <th>Amount</th>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result_payments->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['method_name']; ?></td>
                            <td><?php echo $row['amount']; ?></td>
                            <td><?php echo $row['payment_date']; ?></td>
                            <td><?php echo $row['status']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </section>
    </main>
    <footer>
        <?php include 'footer.html'; ?>
    </footer>
</body>
</html>

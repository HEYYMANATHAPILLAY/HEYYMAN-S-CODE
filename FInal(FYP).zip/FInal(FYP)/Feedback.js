document.addEventListener('DOMContentLoaded', function() {
    function submitFeedback(event) {
        event.preventDefault();

        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const feedback = document.getElementById('feedback').value;

        const feedbackEntry = {
            name: name,
            email: email,
            feedback: feedback
        };

        // Here you would typically send the feedbackEntry to the server
        console.log('Feedback submitted:', feedbackEntry);

        // For now, just display a success message
        alert('Thank you for your feedback!');

        document.getElementById('feedbackForm').reset();
    }

    window.submitFeedback = submitFeedback;
});

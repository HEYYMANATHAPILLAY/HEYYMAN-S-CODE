function validateForgotForm() {
    var newPassword = document.getElementById("new-password").value;
    var confirmPassword = document.getElementById("confirm-password").value;
    var passwordPattern = /^[a-zA-Z0-9]{8,12}$/;

    if (!passwordPattern.test(newPassword)) {
        alert("Password must be 8-12 characters long and contain only letters and numbers.");
        return false;
    }

    if (newPassword !== confirmPassword) {
        alert("Passwords do not match.");
        return false;
    }

    return true;
}

function handleForgotFormSubmit(event) {
    event.preventDefault(); // Prevent the default form submission
    if (validateForgotForm()) {
        alert("Your password has been updated.");
        window.location.href = "login.html"; // Redirect to login.html
    }
}

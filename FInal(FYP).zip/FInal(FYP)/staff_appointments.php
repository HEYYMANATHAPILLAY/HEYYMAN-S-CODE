<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'staff') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['reschedule'])) {
        $appointment_id = $_POST['appointment_id'];
        $appointment_date = $_POST['appointment_date'];

        $stmt = $conn->prepare("UPDATE appointments SET appointment_date=? WHERE appointment_id=?");
        $stmt->bind_param("si", $appointment_date, $appointment_id);
        $stmt->execute();
        $stmt->close();
    } elseif (isset($_POST['assign_staff'])) {
        $appointment_id = $_POST['appointment_id'];
        $staff_id = $_POST['staff_id'];

        // Ensure staff_id is treated as a string
        $staff_id = (string)$staff_id;

        // Check if staff_id exists in users table with role 'staff'
        $stmt = $conn->prepare("SELECT id FROM users WHERE id = ? AND role = 'staff'");
        $stmt->bind_param("s", $staff_id);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // Staff ID is valid, proceed with assignment
            $stmt->close();
            
            $stmt = $conn->prepare("UPDATE appointments SET assigned_staff_id=? WHERE appointment_id=?");
            $stmt->bind_param("si", $staff_id, $appointment_id);
            $stmt->execute();
            $stmt->close();

            // Check if a staff assignment already exists for this appointment
            $stmt = $conn->prepare("SELECT assignment_id FROM staff_assignments WHERE appointment_id = ?");
            $stmt->bind_param("i", $appointment_id);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                // Update the existing staff assignment
                $stmt->close();
                $stmt = $conn->prepare("UPDATE staff_assignments SET staff_id=? WHERE appointment_id=?");
                $stmt->bind_param("si", $staff_id, $appointment_id);
            } else {
                // Insert a new staff assignment
                $stmt->close();
                $stmt = $conn->prepare("INSERT INTO staff_assignments (appointment_id, staff_id) VALUES (?, ?)");
                $stmt->bind_param("is", $appointment_id, $staff_id);
            }
            $stmt->execute();
            $stmt->close();
        } else {
            // Invalid staff_id
            echo "Invalid staff ID.";
            $stmt->close();
        }
    } elseif (isset($_POST['delete'])) {
        $appointment_id = $_POST['appointment_id'];

        // Delete corresponding entries in the staff_assignments table
        $stmt = $conn->prepare("DELETE FROM staff_assignments WHERE appointment_id=?");
        $stmt->bind_param("i", $appointment_id);
        $stmt->execute();
        $stmt->close();

        // Now delete the appointment
        $stmt = $conn->prepare("DELETE FROM appointments WHERE appointment_id=? AND status='Cancelled'");
        $stmt->bind_param("i", $appointment_id);
        $stmt->execute();
        $stmt->close();
    }
}

$appointments = [];
$stmt = $conn->prepare("SELECT a.*, c.make, c.model, u.first_name, u.last_name, s.first_name AS staff_first_name, s.last_name AS staff_last_name 
                        FROM appointments a 
                        JOIN cars c ON a.car_id = c.car_id 
                        JOIN users u ON a.user_id = u.id 
                        LEFT JOIN users s ON a.assigned_staff_id = s.id");
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $appointments[] = $row;
}
$stmt->close();

// Fetch staff members for dropdown
$staff_members = [];
$stmt = $conn->prepare("SELECT id, first_name, last_name FROM users WHERE role='staff'");
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $staff_members[] = $row;
}
$stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Appointments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            background-attachment: fixed;
            background-image:url("background.jpg");
        }
        .container {
            width: 80%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            min-height: calc(100vh - 80px); /* Header and footer height */
        }
        h1, h2 {
            text-align: center;
            color: #333;
        }
        .section {
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .button2 {
            display: inline-block;
            transition: all 0.2s ease-in;
            position: relative;
            overflow: hidden;
            z-index: 1;
            color: #090909;
            padding: 0.7em 1.7em;
            cursor: pointer;
            font-size: 18px;
            border-radius: 0.5em;
            background: #e8e8e8;
            border: 1px solid #e8e8e8;
            box-shadow: 6px 6px 12px #c5c5c5, -6px -6px 12px #ffffff;
        }
        .button2:active {
            color: #666;
            box-shadow: inset 4px 4px 12px #c5c5c5, inset -4px -4px 12px #ffffff;
        }
        .button2:before {
            content: "";
            position: absolute;
            left: 50%;
            transform: translateX(-50%) scaleY(1) scaleX(1.25);
            top: 100%;
            width: 140%;
            height: 180%;
            background-color: rgba(0, 0, 0, 0.05);
            border-radius: 50%;
            display: block;
            transition: all 0.5s 0.1s cubic-bezier(0.55, 0, 0.1, 1);
            z-index: -1;
        }
        .button2:after {
            content: "";
            position: absolute;
            left: 55%;
            transform: translateX(-50%) scaleY(1) scaleX(1.45);
            top: 180%;
            width: 160%;
            height: 190%;
            background-color: #009087;
            border-radius: 50%;
            display: block;
            transition: all 0.5s 0.1s cubic-bezier(0.55, 0, 0.1, 1);
            z-index: -1;
        }
        .button2:hover {
            color: #ffffff;
            border: 1px solid #009087;
        }
        .button2:hover:before {
            top: -35%;
            background-color: #009087;
            transform: translateX(-50%) scaleY(1.3) scaleX(0.8);
        }
        .button2:hover:after {
            top: -45%;
            background-color: #009087;
            transform: translateX(-50%) scaleY(1.3) scaleX(0.8);
        }
    </style>
</head>
<body>
    <header>
        <?php include 'after-login-header-staff.html'; ?>
    </header>
    <div class="container">
        <h1>Appointments Management</h1>

        <div class="section">
            <h2>All Appointments</h2>
            <table>
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Car</th>
                        <th>Service Type</th>
                        <th>Appointment Date</th>
                        <th>Status</th>
                        <th>Assigned Staff</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($appointments as $appointment): ?>
                        <tr>
                            <td><?= htmlspecialchars($appointment['first_name'] . ' ' . $appointment['last_name']); ?></td>
                            <td><?= htmlspecialchars($appointment['make'] . ' ' . $appointment['model']); ?></td>
                            <td><?= htmlspecialchars($appointment['service_type']); ?></td>
                            <td><?= htmlspecialchars($appointment['appointment_date']); ?></td>
                            <td><?= htmlspecialchars($appointment['status']); ?></td>
                            <td>
                                <?php 
                                    if ($appointment['assigned_staff_id']) {
                                        echo htmlspecialchars($appointment['staff_first_name'] . ' ' . $appointment['staff_last_name']);
                                    } else {
                                        echo 'Not assigned';
                                    }
                                ?>
                            </td>
                            <td>
                                <form action="" method="post" style="display: inline;">
                                    <input type="hidden" name="appointment_id" value="<?= $appointment['appointment_id']; ?>">
                                    <input type="datetime-local" name="appointment_date" value="<?= date('Y-m-d\TH:i', strtotime($appointment['appointment_date'])); ?>">
                                    <button type="submit" name="reschedule" class="button2">Reschedule</button>
                                </form>

                                <form action="" method="post" style="display: inline;">
                                    <input type="hidden" name="appointment_id" value="<?= $appointment['appointment_id']; ?>">
                                    <select name="staff_id">
                                        <?php foreach ($staff_members as $staff): ?>
                                            <option value="<?= $staff['id']; ?>" <?= ($appointment['assigned_staff_id'] == $staff['id']) ? 'selected' : ''; ?>>
                                                <?= htmlspecialchars($staff['first_name'] . ' ' . $staff['last_name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" name="assign_staff" class="button2">Assign</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <footer>
        <?php include 'footer.html'; ?>
    </footer>
</body>
</html>

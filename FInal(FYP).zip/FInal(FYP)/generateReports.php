<?php
session_start();
require('fpdf/fpdf.php');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function generatePDF($title, $header, $data) {
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, $title, 0, 1, 'C');
    $pdf->SetFont('Arial', 'B', 12);
    foreach($header as $col) {
        $pdf->Cell(40, 10, $col, 1);
    }
    $pdf->Ln();
    $pdf->SetFont('Arial', '', 12);
    foreach($data as $row) {
        foreach($row as $col) {
            $pdf->Cell(40, 10, $col, 1);
        }
        $pdf->Ln();
    }
    $pdf->Output('D', $title . '.pdf');
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $report_type = $_POST['report_type'];
    $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : $_SESSION['user_id'];

    if ($report_type == 'service_history') {
        $title = "Service History Report";
        $header = ['Service ID', 'Car ID', 'Service Type', 'Last Changed', 'Scheduled Change'];
        $sql = "SELECT service_id, car_id, service_type, last_changed, scheduled_change FROM services WHERE car_id IN (SELECT car_id FROM cars WHERE user_id='$user_id')";
    } elseif ($report_type == 'financial') {
        $title = "Financial Report";
        $header = ['Payment ID', 'User ID', 'Amount', 'Date', 'Status'];
        $sql = "SELECT id, user_id, amount, payment_date, status FROM payments WHERE user_id='$user_id'";
    } elseif ($report_type == 'appointment_analysis') {
        $title = "Appointment Analysis Report";
        $header = ['Appointment ID', 'User ID', 'Car ID', 'Service Type', 'Appointment Date', 'Status', 'Assigned Staff ID'];
        $sql = "SELECT a.appointment_id, a.user_id, a.car_id, a.service_type, a.appointment_date, a.status, sa.staff_id as assigned_staff_id 
                FROM appointments a 
                LEFT JOIN staff_assignments sa ON a.appointment_id = sa.appointment_id 
                WHERE a.user_id='$user_id'";
    } else {
        // Empty report placeholder
        $title = "Report";
        $header = ['N/A'];
        $data = [['This report is not yet implemented']];
        generatePDF($title, $header, $data);
        exit;
    }

    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    } else {
        $data = [['No data available']];
    }
    
    generatePDF($title, $header, $data);
    exit;
}

$sql_users = "SELECT id, email FROM users";
$result_users = $conn->query($sql_users);
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Reports</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            min-height: 100%;
            display: flex;
            flex-direction: column;
            background-color: #CCCCCC;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            background-attachment: fixed;
            background-image: url("background.jpg");
        }
        .container {
            width: 80%;
            margin: auto;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        label {
            margin: 10px 0;
            font-weight: bold;
        }
        select {
            padding: 10px;
            margin: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .submit-button {
            --width: 100px;
            --height: 35px;
            --tooltip-height: 35px;
            --tooltip-width: 90px;
            --gap-between-tooltip-to-button: 18px;
            --button-color: #1163ff;
            --tooltip-color: #fff;
            width: var(--width);
            height: var(--height);
            background: var(--button-color);
            position: relative;
            text-align: center;
            border-radius: 0.45em;
            font-family: "Arial";
            transition: background 0.3s;
        }

        .submit-button::before {
            position: absolute;
            content: attr(data-tooltip);
            width: var(--tooltip-width);
            height: var(--tooltip-height);
            background-color: var(--tooltip-color);
            font-size: 0.9rem;
            color: #111;
            border-radius: .25em;
            line-height: var(--tooltip-height);
            bottom: calc(var(--height) + var(--gap-between-tooltip-to-button) + 10px);
            left: calc(50% - var(--tooltip-width) / 2);
        }

        .submit-button::after {
            position: absolute;
            content: '';
            width: 0;
            height: 0;
            border: 10px solid transparent;
            border-top-color: var(--tooltip-color);
            left: calc(50% - 10px);
            bottom: calc(100% + var(--gap-between-tooltip-to-button) - 10px);
        }

        .submit-button::after,.submit-button::before {
            opacity: 0;
            visibility: hidden;
            transition: all 0.5s;
        }

        .text {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .button-wrapper,.text,.icon {
            overflow: hidden;
            position: absolute;
            width: 100%;
            height: 100%;
            left: 0;
            color: #fff;
        }

        .text {
            top: 0
        }

        .text,.icon {
            transition: top 0.5s;
        }

        .icon {
            color: #fff;
            top: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .icon svg {
            width: 24px;
            height: 24px;
        }

        .submit-button:hover {
            background: #6c18ff;
        }

        .submit-button:hover .text {
            top: -100%;
        }

        .submit-button:hover .icon {
            top: 0;
        }

        .submit-button:hover:before,.submit-button:hover:after {
            opacity: 1;
            visibility: visible;
        }

        .submit-button:hover:after {
            bottom: calc(var(--height) + var(--gap-between-tooltip-to-button) - 20px);
        }

        .submit-button:hover:before {
            bottom: calc(var(--height) + var(--gap-between-tooltip-to-button));
        }
    </style>
</head>
<body>
    <header>
        <?php 
        if ($_SESSION['role'] === 'staff') {
            include 'after-login-header-staff.html';
        } else {
            include 'after-login-header.html';
        }
        ?>
    </header>
    <div class="container">
        <h1>Generate Reports</h1>
        <form method="POST" action="">
            <?php if ($_SESSION['role'] == 'staff'): ?>
                <label for="user_id">Select User:</label>
                <select name="user_id" id="user_id">
                    <?php while($row = $result_users->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>"><?php echo $row['email']; ?></option>
                    <?php endwhile; ?>
                </select>
            <?php endif; ?>
            <label for="report_type">Select Report Type:</label>
            <select name="report_type" id="report_type">
                <option value="service_history">Service History Report</option>
                <option value="financial">Financial Report</option>
                <option value="appointment_analysis">Appointment Analysis Report</option>
            </select>
            <button type="submit" class="submit-button" data-tooltip="Size: 20Mb">
                <div class="button-wrapper">
                    <div class="text">Download</div>
                    <span class="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="2em" height="2em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32">
                            <path fill="currentColor" d="m24.707 15.293l-1.414 1.414L17 9.414V28h-2V9.414l-6.293 7.293l-1.414-1.414L16 5.586l8.707 8.707zM4 4h24v2H4z"/>
                        </svg>
                    </span>
                </div>
            </button>
        </form>
    </div>
    <footer>
        <?php include 'footer.html'; ?>
    </footer>
</body>
</html>

<?php
// Start session for user authentication
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carcarepro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle deletion of feedback
if (isset($_POST['delete'])) {
    $id = $_POST['id'];
    $sql = "DELETE FROM feedback WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
        $feedback_deleted = true;
    } else {
        $feedback_error = "Error deleting feedback: " . $conn->error;
    }
}

// Handle responding to feedback
if (isset($_POST['respond'])) {
    $feedback_id = $_POST['feedback_id'];
    $staff_id = $_SESSION['user_id'];
    $response = $_POST['response'];

    $sql = "INSERT INTO responses (feedback_id, staff_id, response) VALUES ('$feedback_id', '$staff_id', '$response')";
    if ($conn->query($sql) === TRUE) {
        // Update the status of the feedback to "Responded"
        $update_sql = "UPDATE feedback SET status='Responded' WHERE id='$feedback_id'";
        if ($conn->query($update_sql) === TRUE) {
            $response_added = true;
        } else {
            $response_error = "Error updating feedback status: " . $conn->error;
        }
    } else {
        $response_error = "Error adding response: " . $conn->error;
    }
}

// Fetch feedback from the database
$sql = "SELECT f.id, f.user_id, f.guest_name, f.guest_email, f.feedback, f.submitted_at, f.status, r.response, r.responded_at 
        FROM feedback f
        LEFT JOIN responses r ON f.id = r.feedback_id
        ORDER BY f.submitted_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Management - CarCarePro</title>
    <link rel="stylesheet" href="FeedbackManagement.css">
</head>
<body>
    <header>
        <?php include 'after-login-header-staff.html'; ?>
    </header>
    <main>
        <section class="feedback-management">
            <h1>Feedback Management</h1>
            <?php if (isset($feedback_deleted) && $feedback_deleted): ?>
                <p class="success-message">Feedback deleted successfully</p>
            <?php elseif (isset($feedback_error)): ?>
                <p class="error-message"><?php echo $feedback_error; ?></p>
            <?php endif; ?>
            <?php if (isset($response_added) && $response_added): ?>
                <p class="success-message">Response added successfully</p>
            <?php elseif (isset($response_error)): ?>
                <p class="error-message"><?php echo $response_error; ?></p>
            <?php endif; ?>
            <div class="feedback-list">
                <h2>Customer Feedback</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Customer</th>
                            <th>Feedback</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Response</th>
                            <th>Responded At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="feedbackList">
                        <?php
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . htmlspecialchars($row['user_id'] ? $row['user_id'] : $row['guest_name'] . ' (' . $row['guest_email'] . ')') . "</td>";
                                echo "<td>" . htmlspecialchars($row['feedback']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['submitted_at']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['response']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['responded_at']) . "</td>";
                                echo "<td>
                                        <form method='POST' action='" . htmlspecialchars($_SERVER["PHP_SELF"]) . "' style='display:inline;'>
                                            <input type='hidden' name='id' value='" . $row['id'] . "'>
                                            <button type='submit' name='delete' style='background-color: #ff4d4d; color: white; border: none; padding: 10px; border-radius: 5px; cursor: pointer;'>Delete</button>
                                        </form>
                                        <form method='POST' action='" . htmlspecialchars($_SERVER["PHP_SELF"]) . "' style='display:inline;'>
                                            <input type='hidden' name='feedback_id' value='" . $row['id'] . "'>
                                            <textarea name='response' required style='margin-top: 5px; padding: 5px;'></textarea>
                                            <button type='submit' name='respond' style='background-color: #28a745; color: white; border: none; padding: 10px; border-radius: 5px; cursor: pointer; margin-top: 5px;'>Respond</button>
                                        </form>
                                      </td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7'>No feedback found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
    <footer>
        <?php include 'footer.html'; ?>
    </footer>
</body>
</html>


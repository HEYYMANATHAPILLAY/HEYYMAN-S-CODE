document.addEventListener('DOMContentLoaded', function() {
    let feedbacks = [];

    function showAddFeedbackForm() {
        document.getElementById('addFeedbackForm').style.display = 'block';
    }

    function hideAddFeedbackForm() {
        document.getElementById('addFeedbackForm').style.display = 'none';
    }

    function addFeedback(event) {
        event.preventDefault();
        const customer = document.getElementById('customer').value;
        const feedback = document.getElementById('feedback').value;
        const date = document.getElementById('date').value;

        const feedbackEntry = {
            id: feedbacks.length + 1,
            customer: customer,
            feedback: feedback,
            date: date
        };

        feedbacks.push(feedbackEntry);
        displayFeedbacks();
        document.getElementById('addFeedback').reset();
        hideAddFeedbackForm();
    }

    function displayFeedbacks() {
        const feedbackList = document.getElementById('feedbackList');
        feedbackList.innerHTML = '';

        feedbacks.forEach(feedback => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${feedback.customer}</td>
                <td>${feedback.feedback}</td>
                <td>${feedback.date}</td>
                <td class="actions">
                    <button onclick="editFeedback(${feedback.id})">Edit</button>
                    <button onclick="deleteFeedback(${feedback.id})">Delete</button>
                </td>
            `;
            feedbackList.appendChild(row);
        });
    }

    function editFeedback(id) {
        const feedback = feedbacks.find(feedback => feedback.id === id);
        document.getElementById('customer').value = feedback.customer;
        document.getElementById('feedback').value = feedback.feedback;
        document.getElementById('date').value = feedback.date;
        showAddFeedbackForm();

        document.getElementById('addFeedback').onsubmit = function(event) {
            event.preventDefault();
            feedback.customer = document.getElementById('customer').value;
            feedback.feedback = document.getElementById('feedback').value;
            feedback.date = document.getElementById('date').value;
            displayFeedbacks();
            document.getElementById('addFeedback').reset();
            hideAddFeedbackForm();
            document.getElementById('addFeedback').onsubmit = addFeedback;
        };
    }

    function deleteFeedback(id) {
        feedbacks = feedbacks.filter(feedback => feedback.id !== id);
        displayFeedbacks();
    }

    window.showAddFeedbackForm = showAddFeedbackForm;
    window.addFeedback = addFeedback;
    window.editFeedback = editFeedback;
    window.deleteFeedback = deleteFeedback;
});
